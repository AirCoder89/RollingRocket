﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class LevelWinHandler : MonoBehaviour {
    [SerializeField] private TextMeshProUGUI CollectedCoinsTxt;
    [SerializeField] private TextMeshProUGUI BonusCoins;
    [SerializeField] private TextMeshProUGUI TotalCoinsTxt;
    [SerializeField] private GameObject TOTAL;

    [SerializeField] private Button GiftBtn;
    [SerializeField] private Button ADVideoBtn;
    [SerializeField] private UIParticleSystem GiftCoinsFX;
    [SerializeField] private Animator GiftTextAnim;
    [SerializeField] private TextMeshProUGUI GiftText;
    [SerializeField] private TextMeshProUGUI GiftTextinPanel;
    [SerializeField] private GameObject GiftTexGameObj;

    [SerializeField] private Animator ADVidTextAnim;
    [SerializeField] private TextMeshProUGUI ADVidText;
    [SerializeField] private TextMeshProUGUI TotalCoinsPanelTxt;

    [SerializeField] private Button NextLevelBtn;
    [SerializeField] private Button ReplayLevelBtn;
    [SerializeField] private Button MainMenuBtn;

    private int GiftCoins = 0;
    private int levelCoins = 0;
    private int ClearBonus = 0;
    private int TotalCoins = 0;
    private string placementID;

    [SerializeField] private UIParticleSystem LevelCoinsFX;
    [SerializeField] private UIParticleSystem DoubleCoinsFX;

    void Start () {
        
        TotalCoinsPanelTxt.text = SceneHandler.GetInstance().GetTotalCoins().ToString(); //show old TOTAL COINS
        SceneHandler.GetInstance().AddToTotalCoins(SceneHandler.GetInstance().TOTAL_LEVEL_COINS); //Then Save the New one
        StartCoroutine(ShowLevelAndBonusCoins());
        //SceneHandler.GetInstance().SaveTotalCoins(100);
    }
	
    IEnumerator ShowLevelAndBonusCoins()
    {
        //SceneHandler.GetInstance().GetLevelCoins()
        //Mathf.RoundToInt(Random.Range(70,90))
        //levelCoins
        while ( levelCoins < SceneHandler.GetInstance().GetLevelCoins() )
        {
            levelCoins++;
            if(levelCoins < 10)
            {
                CollectedCoinsTxt.text = "00" + levelCoins.ToString();
            }else if (levelCoins >= 10 && levelCoins < 100)
            {
                CollectedCoinsTxt.text = "0" + levelCoins.ToString();
            }else if(levelCoins >= 100)
            {
                CollectedCoinsTxt.text = levelCoins.ToString();
            }

            yield return new WaitForEndOfFrame();

            yield return null;
        }

        TotalCoins += levelCoins;
        //
        //Mathf.RoundToInt(Random.Range(30, 50))
        //clear bonus
        while ( ClearBonus < SceneHandler.GetInstance().GetBonusLevel() )
        {
            ClearBonus++;
            if (ClearBonus < 10)
            {
                BonusCoins.text = "00" + ClearBonus.ToString();
            }
            else if (ClearBonus >= 10 && ClearBonus < 100)
            {
                BonusCoins.text = "0" + ClearBonus.ToString();
            }
            else if (ClearBonus >= 100)
            {
                BonusCoins.text = ClearBonus.ToString();
            }

            //yield return new WaitForSeconds(0.01f);
            yield return new WaitForEndOfFrame();

            yield return null;
        }


        //end
        //show TOTAL and play Coins FX
        TotalCoins += ClearBonus;
        TOTAL.SetActive(true);
        UpdateTotalCoinsTxt();

        LevelCoinsFX.Play();

        //-- add event to btn's
        AddEventListener();
        yield return null;
    }

    private void UpdateTotalCoinsTxt(string extraTxt = "")
    {
        if (TotalCoins < 10)
        {
            TotalCoinsTxt.text = "00" + TotalCoins.ToString() + extraTxt;
        }
        else if (TotalCoins >= 10 && TotalCoins < 100)
        {
            TotalCoinsTxt.text = "0" + TotalCoins.ToString() + extraTxt;
        }
        else if (TotalCoins >= 100)
        {
            TotalCoinsTxt.text = TotalCoins.ToString() + extraTxt;
        }
    }
    private void AddEventListener()
    {
        //gift btn
        if(TotalCoins >= 100)
        {
            GiftBtn.interactable = true;
            GiftBtn.onClick.AddListener(onClickGift);
        }

        //adVideo btn
        if (AdManager.Instance.IsNetworkAvailable())
        {
            placementID = AdManager.Instance.IsRewardVideoReadyToShow();
            if (!placementID.Equals("NULL"))
            {
                ADVideoBtn.interactable = true;
                ADVideoBtn.onClick.AddListener(onClickADVideo);
            }
        }

        //-rest
        NextLevelBtn.onClick.AddListener(GoNextLevel);
        ReplayLevelBtn.onClick.AddListener(GoRepeatLevel);
        MainMenuBtn.onClick.AddListener(GoMainMenu);
    }
    public void GoNextLevel()
    {
        Time.timeScale = 1;
        Time.fixedDeltaTime = 0.02f;
        SceneHandler.GetInstance().RemoveCheckPoint();
        SceneHandler.GetInstance().ResetLevelCoins();
        LoadingBarScript.Instance.LoadScene(SceneHandler.GetInstance().GetNextLevelName(), "level");
    }

    public void GoRepeatLevel()
    {
        Time.timeScale = 1;
        Time.fixedDeltaTime = 0.02f;
        SceneHandler.GetInstance().RemoveCheckPoint();
        SceneHandler.GetInstance().ResetLevelCoins();
        LoadingBarScript.Instance.LoadScene(SceneHandler.GetInstance().GetCurrentLevelName(), "level");
    }

    public void GoMainMenu()
    {
        Time.timeScale = 1;
        Time.fixedDeltaTime = 0.02f;
        SceneHandler.GetInstance().RemoveCheckPoint();
        SceneHandler.GetInstance().ResetLevelCoins();
        LoadingBarScript.Instance.LoadScene("MainMenu", "mainMenu");
        
    }

    public void TEST_BTN()
    {
        print("CLICK");
    }

    public void onClickGift()
    {
        GiftBtn.enabled = false;
        StartCoroutine(DisableGiftBtn());

        GiftCoins = Mathf.RoundToInt(Random.Range(20f, 50f));
        GiftText.text = GiftCoins.ToString();
        SceneHandler.GetInstance().AddToTotalCoins(GiftCoins);
        GiftTextAnim.SetTrigger("onGift");
        GiftCoinsFX.Play();
    }
    IEnumerator DisableGiftBtn()
    {
        yield return new WaitForSeconds(2f);
        GiftTexGameObj.SetActive(true);
        GiftTextinPanel.text = "+ 0" + GiftCoins.ToString();
        GiftBtn.enabled = true;
        GiftBtn.interactable = false;
        GiftBtn.onClick.RemoveListener(onClickGift);
    }

    public void onClickADVideo()
    {
        if (!placementID.Equals("NULL"))
        {
            ADVideoBtn.enabled = false;
            EventHandler.onRewardVideoComplete += RewardVideoComplete;
            EventHandler.onRewardVideoFailed += RewardVideoFailed;
            EventHandler.onRewardVideoSkiped += RewardVideoFailed;
            AdManager.Instance.UnityAd_Show(placementID);
        }
    }
    public void RewardVideoComplete()
    {
        SceneHandler.GetInstance().AddToTotalCoins(SceneHandler.GetInstance().TOTAL_LEVEL_COINS);
        ADVidText.text = TotalCoins.ToString();
        TotalCoins *= 2;
        UpdateTotalCoinsTxt(" x2");
        ADVidTextAnim.SetTrigger("onGift");
        DoubleCoinsFX.Play();
        StartCoroutine(DisableADVideoBtn());
        print("TOTAL:" + SceneHandler.GetInstance().GetTotalCoins());
    }
    IEnumerator DisableADVideoBtn()
    {
        yield return new WaitForSeconds(2f);
        ADVideoBtn.enabled = true;
        RewardVideoFailed();
    }
    public void RewardVideoFailed()
    {
        ADVideoBtn.interactable = false;
        ADVideoBtn.onClick.RemoveListener(onClickADVideo);
    }
}
