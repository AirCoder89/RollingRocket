﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;


public class LevelWinPanelScript : MonoBehaviour {

   /* [SerializeField] private GameObject panel;
    [SerializeField] private Button NextLevelBtn;
    [SerializeField] private Button RepeatLevelBtn;
    // Use this for initialization
    private void Awake()
    {
        EventHandler.onLevelWinEvent += onLevelWin;
        panel.gameObject.SetActive(false);
    }
    private void Start()
    {
        NextLevelBtn.onClick.AddListener(() => onClickNextLevel());
        RepeatLevelBtn.onClick.AddListener(() => onClickRepeatLevel());
    }
    public void onLevelWin()
    {
        EventHandler.onLevelWinEvent -= onLevelWin;
        panel.gameObject.SetActive(true);
        
    }

    void onClickNextLevel()
    {

    }

    void onClickRepeatLevel()
    {
        print("repeat level");
        LevelManager.Instance.RestartLevel();
    }*/
}
