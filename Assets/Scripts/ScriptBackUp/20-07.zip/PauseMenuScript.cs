﻿
using UnityEngine;


public class PauseMenuScript : MonoBehaviour {

    public static bool isOpen = false;
    public static bool CanOpen = true;
    public void OpenMenu()
    {
        if(!isOpen && !GameOverPanelScript.Instance.IsOpen && CanOpen)
        {
            isOpen = true;
            this.gameObject.SetActive(true);
            LevelManager.Instance.PauseGame();
        }
    }

    public void CloseMenu()
    {
        isOpen = false;
            this.gameObject.SetActive(false);
            LevelManager.Instance.ResumeGame();
        
    }
    public void onClickStore()
    {
       
        // CloseMenu();
    }

    public void onClickSettings()
    {
        
        //CloseMenu();
    }

    public void onClickExitGame()
    {
       
        CloseMenu();
        LoadingBarScript.Instance.LoadScene("MainMenu", "mainMenu");
    }

    public void onClickResume()
    {
       
        CloseMenu();
    }

    public void onClickReplay()
    {
        CloseMenu();
        LevelManager.Instance.RestartLevel();
    }


}
