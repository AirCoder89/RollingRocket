﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuScript : MonoBehaviour {

    public GameObject sceneHandler;
    // Use this for initialization
    void Start () {
        PlayerPrefs.SetInt("LateContinue", 0);
        PlayerPrefs.SetInt("isContinue", 0);
        PlayerPrefs.SetInt("isCheckPoint", 0);

        Instantiate(sceneHandler, Vector3.zero, Quaternion.identity);
    }
	
    public void onClickStart()
    {

         LoadingBarScript.Instance.LoadScene("Level01","level");
        // AudioManager.Instance.Play("ClickBtn");
    }

    public void GotoLevelX()
    {
        LoadingBarScript.Instance.LoadScene("lev2", "level");
        //AudioManager.Instance.Play("ClickBtn");
    }

    public void GotoStageClear()
    {
        LoadingBarScript.Instance.LoadScene("LevelWin", "win");
       // AudioManager.Instance.Play("ClickBtn");
    }

}
