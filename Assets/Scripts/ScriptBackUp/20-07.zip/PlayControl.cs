﻿
public class PlayControl{
    public string ControlType;
    public string ButtonSide;
}
