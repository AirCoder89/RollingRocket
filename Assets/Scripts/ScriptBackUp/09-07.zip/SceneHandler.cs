﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneHandler : MonoBehaviour {

   
    private float XCheckPos;
    private float YCheckPos;
    private int LevelCoins=0;
    private int BonusCoins;
    private bool iscontinue = false;
    private bool isLatecontinue = false;
    private bool isCheckedpoint = false;
    
    private float FinalDistance;
    static protected SceneHandler instance;
    private string NextLevelName;
    private string CurrentLevelName = "Level01";

    public void UpdateCoins()
    {
        int totalCoins = GetTotalCoins() + LevelCoins;

        float distance = FinalDistance / 100;
        BonusCoins = Mathf.RoundToInt(distance);
        totalCoins += BonusCoins;

        print("------------------------");
        print("FinalDistance: " + FinalDistance);
        print("FinalDistance /1000: " + distance);
        print("- Coins: " + GetTotalCoins());
        print("- LevelCoins: " + LevelCoins);
        print("- BonusCoins: " + BonusCoins);
        print("- TOTALCoins: " + totalCoins);
        print("------------------------");
    }
    public void SetFinalDistance(float d)
    {
        FinalDistance = d;
    }

    public void SetNextLevelName(string levelName)
    {
        NextLevelName = levelName;
    }
    public string GetNextLevelName()
    {
        return NextLevelName;
    }

    public string GetCurrentLevelName()
    {
        return CurrentLevelName;
    }
    public float GetFinalDistance()
    {
        return FinalDistance;
    }
    // Use this for initialization
    void Start()
    {

        if (instance != null)
        {
            Destroy(this.gameObject);
            return;
        }

        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
        LevelCoins = 0;
        EventHandler.onhitCoin += HitCoin;

        //Purchaser.Instance.BuyNoAds();
    }
    public void SetMaxFuel(float maxFuel)
    {
        PlayerPrefs.SetFloat("MaxFuel", maxFuel);
    }
    public float GetMaxFuel()
    {
        return PlayerPrefs.GetFloat("MaxFuel", 500);
    }
   
    public void ResetLevel()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().RestartLevel();
    }

    public void ContinueLevel()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().ContinueLevel();
    }
    public bool isCheckedPoint()
    {
        return isCheckedpoint;
    }
    public bool isContinue()
    {
        return iscontinue;
    }
    public void SetIsContinue(bool status)
    {
        iscontinue = status;
    }

    public bool isLateContinue()
    {
        return isLatecontinue;
    }
    public void SetIsLateContinue(bool status)
    {
        isLatecontinue = status;
    }

    public void StopBonusCounting()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().StopBonusCounting();
    }
    public void HitMagnet()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().HitMagnetBonus();
    }
    public void HitBigScale()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().HitBigScaleBonus();
    }
    public void HitSmallScale()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().HitSmallScaleBonus();
    }
    public void StartSlowMotion()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().StartSlowMotion();
    }
    public void StopSlowMotion()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().EndSlowMotion();
    }
    public void ResetTime()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().ResetTime();
    }
    public void SetCheckPoint(string nameCP, float Xpos,float Ypos)
    {
        isCheckedpoint = true;
        //IDLastCheckPoint = id;
        PlayerPrefs.SetString("lastCP", nameCP);
        XCheckPos = Xpos;
        YCheckPos = Ypos;
    }

    public void RemoveCheckPoint()
    {
        iscontinue = false;
        isLatecontinue = false;
        isCheckedpoint = false;
        PlayerPrefs.SetString("lastCP", "None");
        XCheckPos = 0;
        YCheckPos = 0;
    }
    public float getXCheckPos()
    {
        return XCheckPos;
    }

    public float getYCheckPos()
    {
        return YCheckPos;
    }

    public Vector3 GetSavedPosition()
    {
        return new Vector3(XCheckPos, YCheckPos, 0);
    }
    public void RemoveLastCheckPointFromScene()
    {
        GameObject[] allCheckPt = GameObject.FindGameObjectsWithTag("CheckPoint");
        string lastCPName = PlayerPrefs.GetString("lastCP", "None");
        if(lastCPName != "None")
        {
            foreach (GameObject CP in allCheckPt)
            {
                if (CP.gameObject.name == lastCPName)
                {
                    Destroy(CP);
                    return;
                }
                /* if(CP.GetComponent<CheckPointScript>().GetID() == IDLastCheckPoint)
                  {
                      Destroy(CP);
                      return;
                  }*/
            }
        }
        
    }
    public static SceneHandler GetInstance()
    {
        return instance;
    }
	
	
    public void LoadLevel(string levelName,string sceneType)
    {
      
    }

    public void SetCurrentLevelName(string levelName)
    {
        CurrentLevelName = levelName;
    }
    public void SaveTotalCoins(int totalCoins)
    {
        PlayerPrefs.SetInt("totalCoins",totalCoins);
    }

    public int GetTotalCoins()
    {
        return PlayerPrefs.GetInt("totalCoins", 0);
    }

    public void HitCoin()
    {
        LevelCoins += 1;
    }
    public int GetLevelCoins()
    {
        return LevelCoins;
    }
    public int GetBonusLevel()
    {
        return BonusCoins;
    }
    public void ResetLevelCoins()
    {
        LevelCoins = 0;
    }
}
