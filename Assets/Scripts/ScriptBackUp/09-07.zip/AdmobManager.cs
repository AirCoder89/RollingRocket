﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using GoogleMobileAds;
using GoogleMobileAds.Api;
using GoogleMobileAds.Common;
using System;

public class AdmobManager : MonoBehaviour {
    public Text DebugTxt;
    public static AdmobManager Instance { set; get; }
    private RewardBasedVideoAd rewardBasedVideo;
    private string bannerID; //Banner (Admob)
    private string rewardVideoID ; //video (Admob)
    private string AppID;
    void Start ()
    {
#if UNITY_ANDROID
     AppID = "ca-app-pub-7308931598839605~2572693887";
#else
      AppID = "unexpected_platform";
#endif


        Instance = this;

        MobileAds.Initialize(rewardVideoID);
        rewardBasedVideo = RewardBasedVideoAd.Instance;

        
        //event
        // Called when an ad request has successfully loaded.
        rewardBasedVideo.OnAdLoaded += RewardVideoLoaded;
        // Called when an ad request failed to load.
        rewardBasedVideo.OnAdFailedToLoad += RewardVideoFailedToLoad;
        // Called when an ad is shown.
        rewardBasedVideo.OnAdOpening += RewardVideoOpened;
        // Called when the ad starts to play.
        rewardBasedVideo.OnAdStarted += RewardVideoStarted;
        // Called when the user should be rewarded for watching a video.
        rewardBasedVideo.OnAdRewarded += RewardVideoRewarded;
        // Called when the ad is closed.
        rewardBasedVideo.OnAdClosed += RewardVideoClosed;
        // Called when the ad click caused the user to leave the application.
        rewardBasedVideo.OnAdLeavingApplication += RewardVideoLeftApplication;
        //load
        this.LoadRewardedVideo();
       
    }

    public void LoadRewardedVideo()
    {
#if UNITY_ANDROID
        rewardVideoID = "ca-app-pub-7308931598839605/7850863301";
        bannerID = "ca-app-pub-7308931598839605/5745652133";
#else
      rewardVideoID = "unexpected_platform";
#endif

        AdRequest _request = new AdRequest.Builder().Build();
        this.rewardBasedVideo.LoadAd(_request, rewardVideoID);
    }
     
    public void ShowRewardedVideo()
    {
        if(rewardBasedVideo.IsLoaded())
        {
            rewardBasedVideo.Show();
        }
        else
        {
            DebugTxt.text = "ad is not loaded yet !";
            Debug.Log("ad is not loaded yet !");
        }
    }



    //----------- Events Listener Functions
    public void RewardVideoLoaded(object sender, EventArgs args)
    {
        MonoBehaviour.print("Reward Video Loaded");
        DebugTxt.text = "Reward Video Loaded";
    }

    public void RewardVideoFailedToLoad(object sender, AdFailedToLoadEventArgs args)
    {
        DebugTxt.text = "Reward Video Failed To Load > " + args.Message;
        MonoBehaviour.print(
            "Reward Video Failed To Load > "
                             + args.Message);
        //try to reLoad
        this.LoadRewardedVideo();
    }
    
    public void RewardVideoOpened(object sender, EventArgs args)
    {
        //pause the action
        DebugTxt.text = "Reward Video Opned";
    }

    public void RewardVideoStarted(object sender, EventArgs args)
    {
        //Mute the audio
        DebugTxt.text = "Reward Video Started";
    }

    public void RewardVideoClosed(object sender, EventArgs args)
    {
        //resume the action and audio etc ..

        //reload the next ad
        this.LoadRewardedVideo();
        DebugTxt.text = "Reward Video Closed/reLoad !";
    }

    public void RewardVideoRewarded(object sender, Reward args)
    {
        
        string type = args.Type;
        double amount = args.Amount;
        DebugTxt.text = "Reward Video Complete: you got " + amount.ToString() + " " + type;
        MonoBehaviour.print(
            "Reward Video Rewarded a : "
                        + amount.ToString() + " of " + type);
    }

    public void RewardVideoLeftApplication(object sender, EventArgs args)
    {
        MonoBehaviour.print("Reward Video Left Application event received");
        DebugTxt.text = "Reward Video Left Application !";
    }

}
