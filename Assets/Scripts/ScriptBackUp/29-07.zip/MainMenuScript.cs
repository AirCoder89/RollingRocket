﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuScript : MonoBehaviour {

   
    // Use this for initialization
    void Start () {
        PlayerPrefs.SetInt("LateContinue", 0);
        PlayerPrefs.SetInt("isContinue", 0);
        PlayerPrefs.SetInt("isCheckPoint", 0);
        
        SceneHandler.GetInstance().Audio.Play("MainGame",true);
    }
	
    public void onClickStart()
    {

         LoadingBarScript.Instance.LoadScene("LevelSelect", "win");
        // AudioManager.Instance.Play("ClickBtn");
    }

    public void GotoSettings()
    {
        LoadingBarScript.Instance.LoadScene("Settings", "win");
        //AudioManager.Instance.Play("ClickBtn");
    }
    public void GotoTheStore()
    {
        LoadingBarScript.Instance.LoadScene("Store", "win");
        //AudioManager.Instance.Play("ClickBtn");
    }
    public void VolumeUp()
    {
        SceneHandler.GetInstance().Audio.SetSoundEffectStatus(false);
    }
    public void GotoStageClear()
    {
        //LoadingBarScript.Instance.LoadScene("LevelWin", "win");
        SceneHandler.GetInstance().Audio.Play("ClickFX");
    }

    public void ShowInterstitial()
    {
        SceneHandler.GetInstance().Admob.showInterstitialAd();
    }
    

    public void onClickFaceBook()
    {

    }

    public void onClickAboutCoder()
    {

    }

    public void onClickMoreGames()
    {
        LoadingBarScript.Instance.LoadScene("Endless", "level");
    }


    public void onClickNoADS()
    {

    }

    public void onDailyGift()
    {

    }

    public void onClickGet50Coins()
    {

    }
}
