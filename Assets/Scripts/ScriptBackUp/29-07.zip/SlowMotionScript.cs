﻿
using UnityEngine;

public class SlowMotionScript : MonoBehaviour {
    private bool isOnSlowMotion = false;
    [SerializeField] private bool MoveOffset = false;
    [SerializeField] private GameObject P1;
    [SerializeField] private GameObject P2;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Ship")
        {
            KillParticleLine();
            ObjectPooler.Instance.SpawnFromPool("SlowMotionFX", ShipController.Instance.GetTransform().position, ShipController.Instance.GetTransform().rotation);
            LevelManager.Instance.StartSlowMotion(MoveOffset);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Ship")
        {
            LevelManager.Instance.EndSlowMotion();
            Destroy(gameObject);
        }
    }

    private void KillParticleLine()
    {
        P1.SetActive(false);
        P2.SetActive(false);
    }
}
