﻿
using UnityEngine;

public class KillStartStation : MonoBehaviour {

	
	void Start () {
        EventHandler.onStartGame += KillMe;
	}
	
	public void KillMe()
    {
        if(gameObject != null)
        {
            EventHandler.onStartGame -= KillMe;
            Destroy(gameObject, 3f);
        }
       
    }
}
