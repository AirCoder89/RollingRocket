﻿/*using System.Collections;

using UnityEngine.UI;
using GoogleMobileAds.Api;
using System;*/
using UnityEngine;

public class AdmobManager : MonoBehaviour {
    /*public static AdmobManager Instance { set; get; }
    private BannerView bannerView;

    public void Start()
    {
        #if UNITY_ANDROID
                string appId = "ca-app-pub-7308931598839605~2572693887";
        #elif UNITY_IPHONE
                    string appId = "ca-app-pub-3940256099942544~1458002511";
        #else
                    string appId = "unexpected_platform";
        #endif

        // Initialize the Google Mobile Ads SDK.
        MobileAds.Initialize(appId);

        this.RequestBanner();
    }


    public void RequestBanner()
    {
        #if UNITY_ANDROID
                string adUnitId = "ca-app-pub-7308931598839605/5745652133";
        #elif UNITY_IPHONE
                  string adUnitId = "ca-app-pub-3940256099942544/2934735716";
        #else
                  string adUnitId = "unexpected_platform";
        #endif

        // Create a 320x50 banner at the top of the screen.
        bannerView = new BannerView(adUnitId, AdSize.Banner, AdPosition.Bottom);

        // Called when an ad request has successfully loaded.
        bannerView.OnAdLoaded += BannerLoaded;
        // Called when an ad request failed to load.
        bannerView.OnAdFailedToLoad += BannerFailToLoad;


        // Create an empty ad request.
        AdRequest request = new AdRequest.Builder().Build();
        // Load the banner with the request.
        bannerView.LoadAd(request);
    }

    void Update()
    {
      // bannerView.Show();
    }

    public void BannerLoaded(object sender, EventArgs args)
    {
        bannerView.Show();
        GameObject txt = GameObject.FindGameObjectWithTag("Respawn");
        if(txt != null)
        {
            txt.GetComponent<Text>().text = "Banner Loaded";
        }
    }
     public void BannerFailToLoad(object sender, EventArgs args)
    {
        this.RequestBanner();
        GameObject txt = GameObject.FindGameObjectWithTag("Respawn");
        if(txt != null)
        {
            txt.GetComponent<Text>().text = "Banner Fail to Load";
        }
    }


    public void ShowBanner()
    {
        bannerView.Show();
    }
    public void HideBanner()
    {
        bannerView.Hide();
    }*/

}
