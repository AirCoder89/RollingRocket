﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;


public class GameOverPanelScript : MonoBehaviour {

    public static GameOverPanelScript Instance;
    
    [SerializeField] private GameObject BodyContinue;
    [SerializeField] private GameObject BodyReplay;
    [SerializeField] private GameObject BodyNoConnection;
    [SerializeField] private GameObject BodyNoCoins;
    [SerializeField] private GameObject BodyNoAds;
    [SerializeField] private Text LevelProgressTxt;
    [SerializeField] private Text TotalCoinsTxt;
    [HideInInspector] public bool IsOpen;
    // Use this for initialization
  
    public  GameOverPanelScript()
    {
        Instance = this;
        IsOpen = false;
    }
    private void OnLevelWasLoaded(int level)
    {
        IsOpen = false;
    }
    public void ShowMe()
    {
        IsOpen = true;
        gameObject.SetActive(true);
        //---GC
        System.GC.Collect();
        //--
        if(gameObject != null)
        {
            LevelProgressTxt.text = GameObject.FindGameObjectWithTag("LevelMapping").GetComponent<LevelMapScript>().GetProgress();
            TotalCoinsTxt.text = SceneHandler.GetInstance().GetTotalCoins().ToString();
        
            //Show Body
            if (SceneHandler.GetInstance().GetisCheckedPoint())
            {
                BodyContinue.gameObject.SetActive(true);
                BodyReplay.gameObject.SetActive(false);
            }
            else
            {
                BodyContinue.gameObject.SetActive(false);
                BodyReplay.gameObject.SetActive(true);
            }
            BodyNoConnection.gameObject.SetActive(false);
            BodyNoCoins.gameObject.SetActive(false);
            BodyNoAds.gameObject.SetActive(false);
        }
    }
    public void onClickWatchAD()
    {
        if(AdManager.Instance.IsNetworkAvailable())
        {
            
            string placementID = AdManager.Instance.IsRewardVideoReadyToShow();
            if (!placementID.Equals("NULL"))
            {
                EventHandler.onRewardVideoComplete += RewardVideoComplete;
                EventHandler.onRewardVideoFailed += RewardVideoFailed;
                AdManager.Instance.UnityAd_Show(placementID);
            }
            else
            {
                NoAds();
            }
        }
        else
        {
            NoConnection();
        }
    }

    public void onClickReplay()
    {
        IsOpen = false;
        SceneHandler.GetInstance().ResetCounter++;
        SceneHandler.GetInstance().RemoveCheckPoint();
        SceneHandler.GetInstance().ResetLevelCoins();
        LevelManager.Instance.RestartLevel();
    }

   
    public void onClickIGiveUp()
    {
        IsOpen = false;
        string PID = AdManager.Instance.IsSimpleVideoReadyToShow();
        if(!PID.Equals("NULL"))
        {
            AdManager.Instance.UnityAd_Show(PID);
        }
        SceneHandler.GetInstance().RemoveCheckPoint();
        SceneHandler.GetInstance().ResetLevelCoins();
        LoadingBarScript.Instance.LoadScene("MainMenu", "mainMenu");
    }

    public void onClickPay100Coins()
    {
        if(SceneHandler.GetInstance().GetTotalCoins() >= 100)
        {
            IsOpen = false;
            SceneHandler.GetInstance().buySomeThing(100); //remove from the total coins >100!
            LevelManager.Instance.ContinueLevel();
        }
        else
        {
            noCoins();
        }
    }

    public void onClickOK_NoConnection()
    {
        BodyContinue.gameObject.SetActive(true);
        BodyNoConnection.gameObject.SetActive(false);
        BodyReplay.gameObject.SetActive(false);
        BodyNoCoins.gameObject.SetActive(false);
        BodyNoAds.gameObject.SetActive(false);
    }

    private void NoConnection()
    {
        BodyNoConnection.gameObject.SetActive(true);
        BodyContinue.gameObject.SetActive(false);
        BodyReplay.gameObject.SetActive(false);
        BodyNoCoins.gameObject.SetActive(false);
        BodyNoAds.gameObject.SetActive(false);
    }
    private void noCoins()
    {
        BodyNoCoins.gameObject.SetActive(true);
        BodyContinue.gameObject.SetActive(false);
        BodyReplay.gameObject.SetActive(false);
        BodyNoConnection.gameObject.SetActive(false);
        BodyNoAds.gameObject.SetActive(false);
    }

    public void NoAds()
    {
        BodyNoAds.gameObject.SetActive(true);
        BodyNoCoins.gameObject.SetActive(false);
        BodyContinue.gameObject.SetActive(false);
        BodyReplay.gameObject.SetActive(false);
        BodyNoConnection.gameObject.SetActive(false);
    }
    public void RewardVideoComplete()
    {
        IsOpen = false;
        EventHandler.onRewardVideoComplete -= RewardVideoComplete;
        LevelManager.Instance.ContinueLevel();

    }
    public void RewardVideoFailed()
    {
        EventHandler.onRewardVideoFailed -= RewardVideoFailed;
        NoAds();
    }
    public void RewardVideoSkiped()
    {

    }

    public void GetMoreCoins()
    {
        //Show a Coins (Offre)!
        
    }
}
