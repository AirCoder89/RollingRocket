﻿using UnityEngine;


public class ShipFollow : MonoBehaviour {
    public Transform target;
    public Transform Moon;
    public Transform CenterLine;
    public Transform StarsSP;
    public Vector3 offset ;
    
    public float Xoffset; //Ship x on the screen
    public float YScale; //lock at scale
    public bool IsSlowMotion;
    private Camera camera;
    private float Smoothing = 120f;
    //private Vector2 SmoothVelocity; 

    private float YOffset;
    private Vector3 moonOffset;
    public Vector3 CenterLineOffset;
    private bool IsMoveOffset;
    private void Start()
    {
        camera = GetComponent<Camera>();
        IsSlowMotion = false;
        IsMoveOffset = false;
        offset = new Vector3(0f, 0f, -15f);
        Xoffset = 12f;//8f;
        YScale = 4f;
        moonOffset = transform.position + Moon.position;
        CenterLineOffset = new Vector3(17.9f, -38.76f, 130) ;
    }
  
    public void StartSlowMotion(bool movingOffset = false)
    {
        IsSlowMotion = true;
        IsMoveOffset = movingOffset;
    }
    public void StopSlowMotion()
    {
        IsSlowMotion = false;
        IsMoveOffset = false;
    }
    private void LateUpdate() //FixedUpdate
    {
        if (!ShipController.Instance.IsAlive)
        {
            return;
        }
        else
        {

            //---try 1
            //transform.position = new Vector3(target.position.x + Xoffset, 0, 0) + offset;
            //---

            //--- try 2
            /*Vector3 _pos = new Vector3(target.position.x + Xoffset, 0, 0) + offset;
             Vector3 smoothedPos = Vector3.Lerp(transform.position, _pos, Smoothing * Time.deltaTime );
             transform.position = smoothedPos;*/
            //---

            //----- try 3
            /*Vector3 v3 = transform.position;
                v3.x = Mathf.Lerp(v3.x, target.position.x + Xoffset, Smoothing * Time.deltaTime);
             transform.position = v3;*/
            //-----

            //--- try 4
            Vector3 _pos = new Vector3(target.position.x + Xoffset, 0, 0) + offset;
            Vector3 smoothedPos = Vector3.Slerp(transform.position, _pos, 120f * Time.deltaTime);
            transform.position = smoothedPos;
            //---

            //----- try 5
            // transform.position = new Vector3(Mathf.SmoothDamp(transform.position.x, target.position.x + Xoffset, ref SmoothVelocity.x, Smoothing * Time.deltaTime), transform.position.y, transform.position.z);
            //-----



            YOffset = target.position.y - (target.position.y / YScale);
            Vector3 lockatPos = new Vector3(target.position.x + Xoffset, target.position.y - YOffset, 0);
            transform.LookAt(lockatPos);
            //stars
            StarsSP.position = new Vector3(target.position.x + 15f, 0, 0);

            if (Moon.gameObject != null) Moon.position = transform.position + moonOffset - new Vector3(70f, 0, 0);
            if (CenterLine != null) CenterLine.position = transform.position + CenterLineOffset - new Vector3(0f, 0, 0);



            //----------
            float zoom = 55;
            if (IsSlowMotion)
            {
                Xoffset = Mathf.Lerp(Xoffset, 6.5f, Time.deltaTime * 1.5f);
                //if (ShipController.Instance != null) ObjectPooler.Instance.SpawnFromPool("SpeedFX", target.position, target.rotation);
                camera.fieldOfView = Mathf.Lerp(camera.fieldOfView, zoom, Time.deltaTime * 1.5f);
                
            }
            else
            {
                Xoffset = Mathf.Lerp(Xoffset, 12f, Time.deltaTime * 1.5f);
                camera.fieldOfView = Mathf.Lerp(camera.fieldOfView, 70f, Time.deltaTime * 2f);
            }


            if(IsMoveOffset)
            {
                offset = Vector3.Lerp(offset, new Vector3(-1f, 0f, -15f), Time.deltaTime * 1.5f);
            }
            else
            {
                offset = Vector3.Lerp(offset, new Vector3(0f, 0f, -15f), Time.deltaTime * 2f);

            }
        }

    }
    
}
