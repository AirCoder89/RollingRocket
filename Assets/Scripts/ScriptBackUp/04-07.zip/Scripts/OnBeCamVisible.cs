﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnBeCamVisible : MonoBehaviour {

 
    /*private void OnBecameInvisible()
    {

        RenderHandler(false);
    }

    private void OnBecameVisible()
    {
        RenderHandler(true);
    }

    private void RenderHandler(bool s)
    {
        SpriteRenderer SP = GetComponent<SpriteRenderer>();
        SP.enabled = s;
    }
    */
}
