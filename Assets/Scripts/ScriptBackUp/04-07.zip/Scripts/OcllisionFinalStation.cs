﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OcllisionFinalStation : MonoBehaviour {
    public GameObject SystemParticle;
    private GameObject Player;
    private float distance;
    void Start()
    {
        Player = GameObject.FindGameObjectWithTag("ShipParent");
        distance = Camera.main.ScreenToWorldPoint(new Vector3(Camera.main.pixelWidth * 2f, 0, 0)).x + 20f;
    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {
            bool isActive = Mathf.Abs(Mathf.Abs(transform.position.x) - Mathf.Abs(Player.transform.position.x)) < distance;
            GetComponent<BoxCollider2D>().enabled = isActive;
            SystemParticle.SetActive(isActive);
            
        }

    }
}
