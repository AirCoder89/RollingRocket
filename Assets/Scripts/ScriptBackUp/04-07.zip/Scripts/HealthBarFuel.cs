﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBarFuel : MonoBehaviour {
    public Image CurrentHp;
    public Text PercentTxt;

    public float CurrentFuel = 500; //hitPoint
    public float MaxHealthBarValue = 500; //maxHitPoint

    private void Start()
    {
        EventHandler.onhitFuel += onhitfuel;
    }
    public void onhitfuel()
    {
        this.AddFuel(200);
    }
    public void InitHP(float maxFuel, float currentFuel)
    {
        CurrentFuel = currentFuel;
        MaxHealthBarValue = maxFuel;
        UpdateHealthBar();
    }

    private void UpdateHealthBar()
    {
        float ratio = CurrentFuel / MaxHealthBarValue;
		if(CurrentHp != null) CurrentHp.rectTransform.localScale = new Vector3(ratio, 1, 1);
        //PercentTxt.text = (ratio * 100).ToString("0") + "%";
		if(PercentTxt != null) PercentTxt.text = CurrentFuel.ToString("0") + "/" + MaxHealthBarValue.ToString("0") ;
    }

    public void ConsumeFuel(float damage)
    {
        CurrentFuel -= damage;
        if(CurrentFuel < 0)
        {
            CurrentFuel = 0;
            EventHandler.FuelEmpty_TR();
        }

        UpdateHealthBar();
    }

    public void AddFuel(float heal)
    {
        CurrentFuel += heal;
        if (CurrentFuel > MaxHealthBarValue)
        {
            CurrentFuel = MaxHealthBarValue;
        }

        UpdateHealthBar();
    }
}
