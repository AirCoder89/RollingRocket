﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;


public class GameOverPanelScript : MonoBehaviour {

    public GameObject panel;
    public Button ContinueBtn;
    public Button ResetBtn;
    // Use this for initialization
    private void Awake()
    {
        EventHandler.onShipDieEvent += ShowMe;
        panel.gameObject.SetActive(false);
    }
    void Start () {
        //add eventListener
       
        ContinueBtn.onClick.AddListener(() => onClickContinue());
        ResetBtn.onClick.AddListener(() => onClickReset());
    }

    public void ShowMe()
    {
        EventHandler.onShipDieEvent -= ShowMe;
        StartCoroutine("showPanel");
    }

    IEnumerator showPanel()
    {
        yield return new WaitForSeconds(1f);
        panel.gameObject.SetActive(true);
    }
    private void onClickContinue()
    {
        SceneHandler.GetInstance().ContinueLevel();
    }

    private void onClickReset()
    {
        SceneHandler.GetInstance().ResetLevel();
    }
	

}
