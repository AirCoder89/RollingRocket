﻿
using UnityEngine;

public class KillGoTxt : MonoBehaviour {

	// Use this for initialization
	void Start () {
        Destroy(gameObject, GetComponentInChildren<ParticleSystem>().main.duration + GetComponentInChildren<ParticleSystem>().main.startLifetime.constantMax);
    }
    private void OnDestroy()
    {
       // print("DESTROY");
    }
}
