﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinalStationScript : MonoBehaviour {

    public GameObject Vortex;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "Ship")
        {
            SetNextLevel();
            SceneHandler.GetInstance().ResetTime();
            EventHandler.LevelWin_TR();
            Vector3 pos = Camera.main.transform.position + new Vector3(0, 0, 15);
            ObjectPooler.Instance.SpawnFromPool("Vortex", pos, Quaternion.identity);
        }
    }

    private void SetNextLevel()
    {
        string currentLevel = SceneHandler.GetInstance().GetCurrentLevelName();
        string nextLevel = "";
        switch(currentLevel)
        {
            case "Level01": nextLevel = "Level0X"; break;
            case "Level02": nextLevel = "Level03"; break;
            case "Level03": nextLevel = "Level04"; break;
            case "Level04": nextLevel = "Level05"; break;
            case "Level05": nextLevel = "Level06"; break;
            default: nextLevel = "Level01"; break;
        }

        SceneHandler.GetInstance().SetNextLevelName(nextLevel);

    }
}
