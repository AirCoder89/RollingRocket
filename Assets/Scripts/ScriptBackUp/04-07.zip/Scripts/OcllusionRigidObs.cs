﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OcllusionRigidObs : MonoBehaviour {
    public bool IsBoxCollider = true;
    private GameObject Player;
    private float distance;
   
   
    // Use this for initialization
    void Start()
    {
        Player = GameObject.FindGameObjectWithTag("ShipParent");
        distance = Camera.main.ScreenToWorldPoint(new Vector3(Camera.main.pixelWidth * 2f, 0, 0)).x + 20f;
    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {
            bool isActive = Mathf.Abs(Mathf.Abs(transform.position.x) - Mathf.Abs(Player.transform.position.x)) < distance;

			//Collider
			if(IsBoxCollider) GetComponent<BoxCollider2D>().enabled = isActive;
			else GetComponent<EdgeCollider2D>().enabled = isActive;

			//sprite renderer
			GetComponent<SpriteRenderer>().enabled = isActive;

			//rigid body
            if(isActive)
            {
                //GetComponent<Rigidbody2D> ().gravityScale = 1f; 
                StartCoroutine("GravityHandler");
            }
            else
            {
                GetComponent<Rigidbody2D> ().gravityScale = 0f; 
                //StartCoroutine("GravityHandler", 0f);
            }


        }

    }

    IEnumerator GravityHandler()
    {
        yield return new WaitForSeconds(2f);
        GetComponent<Rigidbody2D>().gravityScale = 1f;
    }
}
