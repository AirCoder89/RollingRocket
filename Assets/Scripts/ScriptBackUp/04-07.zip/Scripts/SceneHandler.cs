﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneHandler : MonoBehaviour {

   
    private float XCheckPos;
    private float YCheckPos;
    private int LevelCoins;
    private int BonusCoins;
    private bool iscontinue = false;
    private bool isLatecontinue = false;
    private bool isCheckedpoint = false;
    private float MaxFuel = 500;
    private float FinalDistance;
    static protected SceneHandler instance;
    private string NextLevelName;
    private string CurrentLevelName = "Level01";

    public void UpdateCoins()
    {
        int totalCoins = GetTotalCoins() + LevelCoins;

        float distance = FinalDistance / 1000;
        BonusCoins = Mathf.RoundToInt(distance) * 100;
        totalCoins += BonusCoins;

        print("------------------------");
        print("- Coins: " + GetTotalCoins());
        print("- LevelCoins: " + LevelCoins);
        print("- BonusCoins: " + BonusCoins);
        print("- TOTALCoins: " + totalCoins);
        print("------------------------");
    }
    public void SetFinalDistance(float d)
    {
        FinalDistance = d;
    }

    public void SetNextLevelName(string levelName)
    {
        NextLevelName = levelName;
    }
    public string GetNextLevelName()
    {
        return NextLevelName;
    }

    public string GetCurrentLevelName()
    {
        return CurrentLevelName;
    }
    public float GetFinalDistance()
    {
        return FinalDistance;
    }
    // Use this for initialization
    void Start()
    {

        if (instance != null)
        {
            Destroy(this.gameObject);
            return;
        }

        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
        LevelCoins = 0;
        EventHandler.onhitCoin += HitCoin;
        
    }
    public float getMaxFuel()
    {
        return MaxFuel;
    }
    public void ResetLevel()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().RestartLevel();
    }

    public void ContinueLevel()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().ContinueLevel();
    }
    public bool isCheckedPoint()
    {
        return isCheckedpoint;
    }
    public bool isContinue()
    {
        return iscontinue;
    }
    public void SetIsContinue(bool status)
    {
        iscontinue = status;
    }

    public bool isLateContinue()
    {
        return isLatecontinue;
    }
    public void SetIsLateContinue(bool status)
    {
        isLatecontinue = status;
    }

    public void StopBonusCounting()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().StopBonusCounting();
    }
    public void HitMagnet()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().HitMagnetBonus();
    }
    public void StartSlowMotion()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().StartSlowMotion();
    }
    public void StopSlowMotion()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().EndSlowMotion();
    }
    public void ResetTime()
    {
        GameObject.FindGameObjectWithTag("levelManager").GetComponent<LevelManager>().ResetTime();
    }
    public void SetCheckPoint(string nameCP, float Xpos,float Ypos)
    {
        isCheckedpoint = true;
        //IDLastCheckPoint = id;
        PlayerPrefs.SetString("lastCP", nameCP);
        XCheckPos = Xpos;
        YCheckPos = Ypos;
    }

    public void RemoveCheckPoint()
    {
        iscontinue = false;
        isLatecontinue = false;
        isCheckedpoint = false;
        PlayerPrefs.SetString("lastCP", "None");
        XCheckPos = 0;
        YCheckPos = 0;
    }
    public float getXCheckPos()
    {
        return XCheckPos;
    }

    public float getYCheckPos()
    {
        return YCheckPos;
    }

    public Vector3 GetSavedPosition()
    {
        return new Vector3(XCheckPos, YCheckPos, 0);
    }
    public void RemoveLastCheckPointFromScene()
    {
        GameObject[] allCheckPt = GameObject.FindGameObjectsWithTag("CheckPoint");
        string lastCPName = PlayerPrefs.GetString("lastCP", "None");
        if(lastCPName != "None")
        {
            foreach (GameObject CP in allCheckPt)
            {
                if (CP.gameObject.name == lastCPName)
                {
                    Destroy(CP);
                    return;
                }
                /* if(CP.GetComponent<CheckPointScript>().GetID() == IDLastCheckPoint)
                  {
                      Destroy(CP);
                      return;
                  }*/
            }
        }
        
    }
    public static SceneHandler GetInstance()
    {
        return instance;
    }
	
	
    public void LoadLevel(string levelName,bool isLevel)
    {
        if(isLevel)
        {
            CurrentLevelName = levelName;
        }
        
        print("Level name:" + levelName);
        //CheckPointScript.ResetID();
        SceneManager.LoadScene(levelName);
    }

    public void SaveTotalCoins(int totalCoins)
    {
        PlayerPrefs.SetInt("totalCoins",totalCoins);
    }

    public int GetTotalCoins()
    {
        return PlayerPrefs.GetInt("totalCoins", 0);
    }

    public void HitCoin()
    {
        LevelCoins += 100;
    }
    public int GetLevelCoins()
    {
        return LevelCoins;
    }
    public int GetBonusLevel()
    {
        return BonusCoins;
    }
    public void ResetLevelCoins()
    {
        LevelCoins = 0;
    }
}
