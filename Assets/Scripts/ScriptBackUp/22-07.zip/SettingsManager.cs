﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SettingsManager : MonoBehaviour {
    public static SettingsManager Instance;
    public PlayControl PC;
    public bool VibrationStatus;
    
	// Use this for initialization
	void Start () {
        Instance = this;
	}
	
    public void SetTapScreenControl()
    {
        this.PC = new PlayControl();
        PC.ControlType = "Tap";
        PC.ButtonSide = "NULL";
    }

    public void SetButtonControl(string buttonSide)
    {
        this.PC = new PlayControl();
        PC.ControlType = "Button";
        PC.ButtonSide = buttonSide;
    }

    public void UpdateVibration()
    {
        VibrationStatus = !VibrationStatus;
    }


    //***************** GET SET ******************************
    // -- Get
    // -- Set
}
