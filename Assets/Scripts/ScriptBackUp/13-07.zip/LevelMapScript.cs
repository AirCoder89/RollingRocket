﻿
using UnityEngine;
using UnityEngine.UI;

public class LevelMapScript : MonoBehaviour {

    [SerializeField] private Transform Ship;
    [SerializeField] private Slider sliderBar;
    public float FinalPosition;
    private float Ratio = 0;
    
    public string GetProgress()
    {
        return (Ratio * 100).ToString("0") + "%";
    }
   
	void Update () {
		if(ShipController.Instance == null)
        {
            return;
        }
      
            Ratio = Ship.position.x / FinalPosition;
            sliderBar.value = Ratio;
        
	}
}
