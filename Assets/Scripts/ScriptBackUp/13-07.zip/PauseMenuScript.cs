﻿
using UnityEngine;


public class PauseMenuScript : MonoBehaviour {

    public void OpenMenu()
    {
       
            this.gameObject.SetActive(true);
            LevelManager.Instance.PauseGame(); 
    }

    public void CloseMenu()
    {
       
            this.gameObject.SetActive(false);
            LevelManager.Instance.ResumeGame();
        
    }
    public void onClickStore()
    {
       
        // CloseMenu();
    }

    public void onClickSettings()
    {
        
        //CloseMenu();
    }

    public void onClickExitGame()
    {
       
        CloseMenu();
        LoadingBarScript.Instance.LoadScene("MainMenu", "mainMenu");
    }

    public void onClickResume()
    {
       
        CloseMenu();
    }

    public void onClickReplay()
    {
        CloseMenu();
        LevelManager.Instance.RestartLevel();
    }


}
