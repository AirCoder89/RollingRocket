﻿
using UnityEngine;

public class FuelScript : MonoBehaviour {
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Ship")
        {

            ObjectPooler.Instance.SpawnFromPool("FuelFX", transform.position, Quaternion.identity);
            Destroy(this.gameObject);
			
            LevelManager.Instance.HitFuel();
        }
    }
}
