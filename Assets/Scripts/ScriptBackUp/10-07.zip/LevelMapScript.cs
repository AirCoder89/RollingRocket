﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelMapScript : MonoBehaviour {

    //public static LevelMapScript Instance;
    [SerializeField] private Transform Ship;
    public float FinalPosition;
    private float Ratio = 0;
    private bool isShipAlive;
    [SerializeField] private Slider sliderBar;
    void Start () {
        //Instance = this;
        isShipAlive = true;
        EventHandler.onShipDieEvent += SetShipAlive;
    }
	
    public void SetShipAlive()
    {
        EventHandler.onShipDieEvent -= SetShipAlive;
        isShipAlive = false;
    }
	// Update is called once per frame
	void Update () {
		if(isShipAlive)
        {
            Ratio = Ship.position.x / FinalPosition;
            sliderBar.value = Ratio;
        }
	}
}
