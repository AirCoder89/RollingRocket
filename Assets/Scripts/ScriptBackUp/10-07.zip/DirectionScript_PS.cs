﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DirectionScript_PS : MonoBehaviour {

    [Range(0,360)] public float Direction;
    private GameObject Player;
    private float distance;
    public ParticleSystem Ps1;
    public ParticleSystem Ps2;
   
    // Use this for initialization
    void Start()
    {
		var mainPS1 = Ps1.main;
		var mainPS2 = Ps2.main;
		mainPS1.startRotation = mainPS2.startRotation = Direction;

        Player = GameObject.FindGameObjectWithTag("ShipParent");
        distance = Camera.main.ScreenToWorldPoint(new Vector3(Camera.main.pixelWidth * 2f, 0, 0)).x + 20f;
    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {
            bool isActive = Mathf.Abs(Mathf.Abs(transform.position.x) - Mathf.Abs(Player.transform.position.x)) < distance; ;

            var emmission = Ps1.emission;
            emmission.enabled = isActive;

            var emmission2 = Ps2.emission;
            emmission2.enabled = isActive;
           
           
        }

       
    }
}
