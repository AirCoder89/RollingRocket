﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour {

    public static LevelManager Instance;
    private float TimeMagnet = 10f; //10 sec
    private float TimeScale = 10f; //10 sec
    public Text MagnetTxt;
    public Text ScaleTxt;
    private GameObject ship;

    
    public GameObject Ship { get { return ship; } set { ship = value; } }
    private ShipController ShipScript;
    public FuelProgressBar ProgressBarFuel;
    private bool isOnSlowMotion = false;
    private float FixedTime;
    private bool isGamePaused;
    private float OldTimeScale;
    private float SavedDistance;
	// Use this for initialization
	void Start () {
        Instance = this;
        isGamePaused = false;
        FixedTime = Time.fixedDeltaTime;
        print("FTime: " + FixedTime);
        EventHandler.onClickContinueEvent += ContinueLevel;
        EventHandler.onClickRestartEvent += RestartLevel;
        
        
        //HPFuel = GetComponent<HealthBarFuel>();
        Ship = GameObject.FindGameObjectWithTag("ShipParent");
        ShipScript = ship.GetComponent<ShipController>();
        

        if (SceneManager.GetActiveScene().name == "Level01") InitLevel01();
        else if (SceneManager.GetActiveScene().name == "Level02") InitLevel02();

        AfterInit();
    }
   
    public void PauseGame()
    {
        if (!isGamePaused)
        {
            ShipScript.isGamePaused = true;
            OldTimeScale = Time.timeScale;
            isGamePaused = true;
            Time.timeScale = 0;
        }
    }
    public void ResumeGame()
    {
        if (isGamePaused)
        {
            ShipScript.isGamePaused = false;
            isGamePaused = false;
            Time.timeScale = OldTimeScale;
        }
    }
   
    public void HitMagnetBonus()
    {
        if(!ShipScript.isOnMagnet)
        {
            MagnetTxt.text = TimeMagnet.ToString("F");
            ShipScript.isOnMagnet = true;
            InvokeRepeating("CountMagnet", 0.0f, 0.01f);
        }
       
    }

    public void HitBigScaleBonus()
    {
        ShipScript.SetScale("Big");
        ScaleTxt.text = TimeScale.ToString("F");
        CancelInvoke("CountScale");
        InvokeRepeating("CountScale", 0.0f, 0.01f);
    }
    public void HitSmallScaleBonus()
    {
        ShipScript.SetScale("Small");
        ScaleTxt.text = TimeScale.ToString("F");
        CancelInvoke("CountScale");
        InvokeRepeating("CountScale", 0.0f, 0.01f);
    }
   
    public void CountScale()
    {
        if (TimeScale <= 0f)
        {
            ScaleTxt.text = "0.00";
            TimeScale = 10f;
            ShipScript.SetScale("Normal");
            CancelInvoke("CountScale");
        }
        else
        {
            TimeScale -= 0.01f;
            ScaleTxt.text = TimeScale.ToString("F");
        }
    }
    public void CountMagnet()
    {
        if(TimeMagnet <= 0f)
        {
            MagnetTxt.text = "0.00";
            TimeMagnet = 10f;
            ShipScript.isOnMagnet = false;
            CancelInvoke("CountMagnet");
        }
        else
        {
            TimeMagnet -=0.01f;
            MagnetTxt.text = TimeMagnet.ToString("F");
        }
    }
    public void StartSlowMotion()
    {
        GameObject.FindGameObjectWithTag("MainCamera").GetComponent<ShipFollow>().StartSlowMotion();
        Time.timeScale = 0.7f;
        Time.fixedDeltaTime = Time.timeScale * .02f;
    }

    public void EndSlowMotion()
    {
        GameObject.FindGameObjectWithTag("MainCamera").GetComponent<ShipFollow>().StopSlowMotion();
        isOnSlowMotion = true;
        print("EndSlowMotion");
       // Time.timeScale = 1f;
       // Time.fixedDeltaTime = 0.02f;
    }

    private void Update()
    {
       
        float slowMotionLength = 3f; //time of transition between slow motion and normal speed
        if (isOnSlowMotion)
        {
            Time.timeScale += (1f / slowMotionLength) * Time.unscaledDeltaTime;
            Time.timeScale = Mathf.Clamp(Time.timeScale,0f,1f);
            if (Time.timeScale >= 1f) { isOnSlowMotion = false; Time.fixedDeltaTime = FixedTime;
               
            }

        }
    }
    public void StopBonusCounting()
    {
        CancelInvoke();
        MagnetTxt.text = "0.00";
        ScaleTxt.text = "0.00";
        //reset scale and turn magnet off
        TimeMagnet = 5f;
        ShipScript.isOnMagnet = false;
    }
    public void ResetTime()
    {
        Time.timeScale = 1f;
        Time.fixedDeltaTime = 0.02f;
    }
    public void UpdateFuelProgressBar(float fuelConsume)
    {
        ProgressBarFuel.ConsumeFuel(fuelConsume);
    }
   
    //************* Init Levels
    private void InitLevel01()
    {
        SceneHandler.GetInstance().SetMaxFuel(500);
        ProgressBarFuel.InitProgressBar(500);
        ShipScript.InitShip();
    }
   
    private void InitLevel02()
    {
        
    }



	private void AfterInit()
	{
		if (SceneHandler.GetInstance().isContinue() && SceneHandler.GetInstance().isCheckedPoint()) {
            //set the player position
            ship.transform.position = SceneHandler.GetInstance().GetSavedPosition();
            SceneHandler.GetInstance().RemoveLastCheckPointFromScene();
            SceneHandler.GetInstance().SetIsContinue(false);
            SceneHandler.GetInstance().SetIsLateContinue(true);
		}
	}
    //********************************************
	//---------- Restart Level
    public void RestartLevel()
    {
        EventHandler.onClickRestartEvent -= RestartLevel;
        SceneHandler.GetInstance().RemoveCheckPoint();
        SceneHandler.GetInstance().ResetLevelCoins();
       
        LoadingBarScript.Instance.LoadScene(SceneManager.GetActiveScene().name,"level");
    }

	//-------- Continue Level
    
    public void ContinueLevel()
    {
        EventHandler.onClickContinueEvent -= ContinueLevel;
        if (SceneHandler.GetInstance().isCheckedPoint()) {

            //-- set Continue flag to true
            SceneHandler.GetInstance().SetIsContinue(true);

            //restart level
            LoadingBarScript.Instance.LoadScene(SceneManager.GetActiveScene().name, "level");
        }
       
    }
}
