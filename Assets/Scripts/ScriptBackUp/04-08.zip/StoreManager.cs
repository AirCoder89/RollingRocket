﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StoreManager : MonoBehaviour {

    //GUI Components
    [SerializeField] private TextMeshProUGUI TotalCoinsTxt;
    [SerializeField] private GameObject BuyCoinsDialog;
    [SerializeField] private Button BackBtn;


    [SerializeField] private TextMeshProUGUI CurrentRotationSpeed;
    [SerializeField] private TextMeshProUGUI NextRotationSpeed;
    [SerializeField] private TextMeshProUGUI RotationSpeedPriceTxt;
    [SerializeField] private Button UpgradeRotationSpeedBtn;
    [SerializeField] private Image RotationSpeedCoinsIcon;

    [SerializeField] private TextMeshProUGUI CurrentFuelConusme;
    [SerializeField] private TextMeshProUGUI NextFuelConusme;
    [SerializeField] private TextMeshProUGUI FuelConusmePriceTxt;
    [SerializeField] private Button UpgradeFuelConusmeBtn;
    [SerializeField] private Image FuelConusmeCoinsIcon;

    [SerializeField] private TextMeshProUGUI CurrentFuelTank;
    [SerializeField] private TextMeshProUGUI NextFuelTank;
    [SerializeField] private TextMeshProUGUI FuelTankPriceTxt;
    [SerializeField] private Button UpgradeFuelTankBtn;
    [SerializeField] private Image FuelTankCoinsIcon;

    [SerializeField] private TextMeshProUGUI CurrentThrust;
    [SerializeField] private TextMeshProUGUI NextThrust;
    [SerializeField] private TextMeshProUGUI ThrustPriceTxt;
    [SerializeField] private Button UpgradeThrustBtn;
    [SerializeField] private Image ThrustCoinsIcon;

    [SerializeField] private TextMeshProUGUI CurrentMagnet;
    [SerializeField] private TextMeshProUGUI NextMagnet;
    [SerializeField] private TextMeshProUGUI MagnetPriceTxt;
    [SerializeField] private Button UpgradeMagnetBtn;
    [SerializeField] private Image MagnetCoinsIcon;

    [SerializeField] private TextMeshProUGUI CurrentSenstivity;
    [SerializeField] private TextMeshProUGUI NextSenstivity;
    [SerializeField] private TextMeshProUGUI SenstivityPriceTxt;
    [SerializeField] private Button UpgradeSenstivityBtn;
    [SerializeField] private Image SenstivityCoinsIcon;

    //Private Declare
    private ShipData ship;
    private int TotalCoins;
    private int Price_RotationSpeed;
    private int Price_Thrust;
    private int Price_FuelConsume;
    private int Price_FuelTank;
    private int Price_Magnet;
    private int Price_Senstivity;
	void Start () {
        ship = new ShipData();
        EventHandler.onBuyCoinsEvent += UpdateTotalCoins;
        BackBtn.onClick.AddListener(onClickBACK);
        UpdateTotalCoins();
        UpdateGui();
	}
	
    private void BtnSoundFX()
    {

    }
    public void onClickBACK()
    {
        LoadingBarScript.Instance.LoadScene("MainMenu", "win");
    }
    private void UpdateTotalCoins()
    {
        TotalCoins = SceneHandler.GetInstance().GetTotalCoins();
        if(TotalCoins < 10)
        {
            TotalCoinsTxt.text = "000" + TotalCoins.ToString();
        }
        else if (TotalCoins >= 10 && TotalCoins < 100)
        {
            TotalCoinsTxt.text = "00" + TotalCoins.ToString();
        }
        else if (TotalCoins >= 100 && TotalCoins < 1000)
        {
            TotalCoinsTxt.text = "0" + TotalCoins.ToString();
        }
        else
        {
            TotalCoinsTxt.text = TotalCoins.ToString();
        }
    }

    private void UpdateGui()
    {
        UpdateSpeedRotationGUI();
        UpdateFuelConsumptionGUI();
        UpdateFuelTankGUI();
        UpdateThrustGUI();
        UpdateMagnetGUI();
        UpdateSenstivityGUI();
    }

    //-------------------- SENSTIVITY
    private void UpdateSenstivityGUI()
    {
        //current level
        int currentLevel = ship.GetLevelSenstivity(); //start from 0 to 3

        //update levels text
        CurrentSenstivity.text = "LEVEL 0" + (currentLevel + 1).ToString() + " >";
        if (currentLevel < 3)
        {
            NextSenstivity.text = "LEVEL 0" + (currentLevel + 2).ToString();
            SetCostSenstivity(currentLevel + 1);
            this.UpgradeSenstivityBtn.onClick.AddListener(UpgradeSenstivity);
        }
        else
        {
            NextSenstivity.text = "MAX";
            NextSenstivity.color = new Color(195, 63, 63, 255); // Dark Red
            //disable the btn
            this.UpgradeSenstivityBtn.interactable = false;
            this.SenstivityCoinsIcon.enabled = false;
            this.SenstivityPriceTxt.text = "MAX";
            this.SenstivityPriceTxt.color = new Color(75, 123, 96, 255); //dark green color
        }
    }
    private void SetCostSenstivity(int Nextlevel)
    {
        switch (Nextlevel)
        {
            case 1: Price_Senstivity = 220; break; //level 02
            case 2: Price_Senstivity = 430; break; //level 03
            case 3: Price_Senstivity = 622; break; //level 04
        }

        this.SenstivityPriceTxt.text = Price_Senstivity.ToString();
    }

    private void UpgradeSenstivity()
    {
        BtnSoundFX();
        if (TotalCoins >= Price_Senstivity)
        {
            int NextLevel = ship.GetLevelSenstivity() + 1;
            if (NextLevel <= 3)
            {
                ship.SetSenstivity(NextLevel);
                SceneHandler.GetInstance().buySomeThing(Price_Senstivity);
                UpdateTotalCoins();
                UpdateSenstivityGUI();
                UpgradeAnimation();
            }
        }
        else
        {
            MORE_COINS_DIALOG();
        }
    }
    //-------------------- MAGNET
    private void UpdateMagnetGUI()
    {
        //current level
        int currentLevel = ship.GetLevelMagnet(); //start from 0 to 3

        //update levels text
        CurrentMagnet.text = "LEVEL 0" + (currentLevel + 1).ToString() + " >";
        if (currentLevel < 3)
        {
            NextMagnet.text = "LEVEL 0" + (currentLevel + 2).ToString();
            SetCostMagnet(currentLevel + 1);
            this.UpgradeMagnetBtn.onClick.AddListener(UpgradeMagnet);
        }
        else
        {
            NextMagnet.text = "MAX";
            NextMagnet.color = new Color(195, 63, 63, 255); // Dark Red
            //disable the btn
            this.UpgradeMagnetBtn.interactable = false;
            this.MagnetCoinsIcon.enabled = false;
            this.MagnetPriceTxt.text = "MAX";
            this.MagnetPriceTxt.color = new Color(75, 123, 96, 255); //dark green color
        }
    }
    private void SetCostMagnet(int Nextlevel)
    {
        switch (Nextlevel)
        {
            case 1: Price_Magnet = 370; break; //level 02
            case 2: Price_Magnet = 599; break; //level 03
            case 3: Price_Magnet = 825; break; //level 04
        }

        this.MagnetPriceTxt.text = Price_Magnet.ToString();
    }

    private void UpgradeMagnet()
    {
        BtnSoundFX();
        if (TotalCoins >= Price_Magnet)
        {
            int NextLevel = ship.GetLevelMagnet() + 1;
            if (NextLevel <= 3)
            {
                ship.SetMagnet(NextLevel);
                SceneHandler.GetInstance().buySomeThing(Price_Magnet);
                UpdateTotalCoins();
                UpdateMagnetGUI();
                UpgradeAnimation();
            }
        }
        else
        {
            MORE_COINS_DIALOG();
        }
    }
    //-------------------- THRUST
    private void UpdateThrustGUI()
    {
        //current level
        int currentLevel = ship.GetLevelThrust(); //start from 0 to 3

        //update levels text
        CurrentThrust.text = "LEVEL 0" + (currentLevel + 1).ToString() + " >";
        if (currentLevel < 3)
        {
            NextThrust.text = "LEVEL 0" + (currentLevel + 2).ToString();
            SetCostThrust(currentLevel + 1);
            this.UpgradeThrustBtn.onClick.AddListener(UpgradeThrust);
        }
        else
        {
            NextThrust.text = "MAX";
            NextThrust.color = new Color(195, 63, 63, 255); // Dark Red
            //disable the btn
            this.UpgradeThrustBtn.interactable = false;
            this.ThrustCoinsIcon.enabled = false;
            this.ThrustPriceTxt.text = "MAX";
            this.ThrustPriceTxt.color = new Color(75, 123, 96, 255); //dark green color
        }
    }
    private void SetCostThrust(int Nextlevel)
    {
        switch (Nextlevel)
        {
            case 1: Price_Thrust = 415; break; //level 02
            case 2: Price_Thrust = 674; break; //level 03
            case 3: Price_Thrust = 939; break; //level 04
        }

        this.ThrustPriceTxt.text = Price_Thrust.ToString();
    }

    private void UpgradeThrust()
    {
        BtnSoundFX();
        if (TotalCoins >= Price_Thrust)
        {
            int NextLevel = ship.GetLevelThrust() + 1;
            if (NextLevel <= 3)
            {
                ship.SetThrust(NextLevel);
                SceneHandler.GetInstance().buySomeThing(Price_Thrust);
                UpdateTotalCoins();
                UpdateThrustGUI();
                UpgradeAnimation();
            }
        }
        else
        {
            MORE_COINS_DIALOG();
        }
    }
    //-------------------- FUEL TANK
    private void UpdateFuelTankGUI()
    {
        //current level
        int currentLevel = ship.GetLevelFuelTank(); //start from 0 to 3

        //update levels text
        CurrentFuelTank.text = "LEVEL 0" + (currentLevel + 1).ToString() + " >";
        if (currentLevel < 3)
        {
            NextFuelTank.text = "LEVEL 0" + (currentLevel + 2).ToString();
            SetCostFuelTank(currentLevel + 1);
            this.UpgradeFuelTankBtn.onClick.AddListener(UpgradeFuelTank);
        }
        else
        {
            NextFuelTank.text = "MAX";
            NextFuelTank.color = new Color(195, 63, 63, 255); // Dark Red
            //disable the btn
            this.UpgradeFuelTankBtn.interactable = false;
            this.FuelTankCoinsIcon.enabled = false;
            this.FuelTankPriceTxt.text = "MAX";
            this.FuelTankPriceTxt.color = new Color(75, 123, 96, 255); //dark green color
        }
    }
    private void SetCostFuelTank(int Nextlevel)
    {
        switch (Nextlevel)
        {
            case 1: Price_FuelTank = 320; break; //level 02
            case 2: Price_FuelTank = 550; break; //level 03
            case 3: Price_FuelTank = 899; break; //level 04
        }

        this.FuelTankPriceTxt.text = Price_FuelTank.ToString();
    }

    private void UpgradeFuelTank()
    {
        BtnSoundFX();
        if (TotalCoins >= Price_FuelTank)
        {
            int NextLevel = ship.GetLevelFuelTank() + 1;
            if (NextLevel <= 3)
            {
                ship.SetFuelTank(NextLevel);
                SceneHandler.GetInstance().buySomeThing(Price_FuelTank);
                UpdateTotalCoins();
                UpdateFuelTankGUI();
                UpgradeAnimation();
            }
        }
        else
        {
            MORE_COINS_DIALOG();
        }
    }
    //-------------------- FUEL CONSUMPTION
    private void UpdateFuelConsumptionGUI()
    {
        //current level
        int currentLevel = ship.GetLevelFuelConsume(); //start from 0 to 3

        //update levels text
        CurrentFuelConusme.text = "LEVEL 0" + (currentLevel + 1).ToString() + " >";
        if (currentLevel < 3)
        {
            NextFuelConusme.text = "LEVEL 0" + (currentLevel + 2).ToString();
            SetCostFuelConsumption(currentLevel + 1);
            this.UpgradeFuelConusmeBtn.onClick.AddListener(UpgradeFuelConsume);
        }
        else
        {
            NextFuelConusme.text = "MAX";
            NextFuelConusme.color = new Color(195, 63, 63, 255); // Dark Red
            //disable the btn
            this.UpgradeFuelConusmeBtn.interactable = false;
            this.FuelConusmeCoinsIcon.enabled = false;
            this.FuelConusmePriceTxt.text = "MAX";
            this.FuelConusmePriceTxt.color = new Color(75, 123, 96, 255); //dark green color
        }
    }

    private void SetCostFuelConsumption(int Nextlevel)
    {
        switch (Nextlevel)
        {
            case 1: Price_FuelConsume = 350; break; //level 02
            case 2: Price_FuelConsume = 700; break; //level 03
            case 3: Price_FuelConsume = 950; break; //level 04
        }

        this.FuelConusmePriceTxt.text = Price_FuelConsume.ToString();
    }

    private void UpgradeFuelConsume()
    {
        BtnSoundFX();
        if (TotalCoins >= Price_FuelConsume)
        {
            int NextLevel = ship.GetLevelFuelConsume() + 1;
            if (NextLevel <= 3)
            {
                ship.SetFuelConsume(NextLevel);
                SceneHandler.GetInstance().buySomeThing(Price_FuelConsume);
                UpdateTotalCoins();
                UpdateFuelConsumptionGUI();
                UpgradeAnimation();
            }
        }
        else
        {
            this.UpgradeFuelConusmeBtn.onClick.RemoveAllListeners();
            MORE_COINS_DIALOG();
        }
    }
    //-------------------- SPEED ROTATION
    private void UpdateSpeedRotationGUI()
    {
        //current level
        int currentLevel = ship.GetLevelSpeedRotation(); //start from 0 to 3

        //update levels text
        CurrentRotationSpeed.text = "LEVEL 0" + (currentLevel + 1).ToString() + " >";
        if(currentLevel < 3)
        {
            NextRotationSpeed.text = "LEVEL 0" + (currentLevel + 2).ToString();
            SetCostRotationSpeed(currentLevel +1);
            this.UpgradeRotationSpeedBtn.onClick.AddListener(UpgradeRotationSpeed);
        }
        else
        {
            NextRotationSpeed.text = "MAX";
            NextRotationSpeed.color = new Color(195, 63, 63, 255); // Dark Red
            //disable the btn
            this.UpgradeRotationSpeedBtn.interactable = false;
            this.RotationSpeedCoinsIcon.enabled = false;
            this.RotationSpeedPriceTxt.text = "MAX";
            this.RotationSpeedPriceTxt.color = new Color(75, 123, 96, 255); //dark green color
        }
    }

    private void SetCostRotationSpeed(int Nextlevel)
    {
        switch(Nextlevel)
        {
            case 1: Price_RotationSpeed = 350; break; //level 02
            case 2: Price_RotationSpeed = 640; break; //level 03
            case 3: Price_RotationSpeed = 862; break; //level 04
        }

        this.RotationSpeedPriceTxt.text = Price_RotationSpeed.ToString();
    }

    private void UpgradeRotationSpeed()
    {
        BtnSoundFX();
        if (TotalCoins >= Price_RotationSpeed)
        {
            int NextLevel = ship.GetLevelSpeedRotation() + 1;
            if(NextLevel <= 3)
            {
                ship.SetSpeedRotation(NextLevel);
                SceneHandler.GetInstance().buySomeThing(Price_RotationSpeed);
                UpdateTotalCoins();
                UpdateSpeedRotationGUI();
                UpgradeAnimation();
            }
        }
        else
        {
            MORE_COINS_DIALOG();
        }
    }


    //------------------------------------------------------------------------
    //------------------------------------------------------------------------
    private void UpgradeAnimation()
    {

    }
    private void MORE_COINS_DIALOG()
    {
        if (!BuyCoinsDialogScript.isOpen)
        {
            BuyCoinsDialog.SetActive(true);
            BuyCoinsDialog.GetComponent<BuyCoinsDialogScript>().Show();
        }
    }
}
