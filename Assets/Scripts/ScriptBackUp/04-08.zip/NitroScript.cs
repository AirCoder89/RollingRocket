﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NitroScript : MonoBehaviour {
    [SerializeField] private GameObject P1;
    [SerializeField] private GameObject P2;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Ship")
        {
            print("SHIP ANGLE = " + ShipController.Instance.GetAngle());
            KillParticleLine();
            ObjectPooler.Instance.SpawnFromPool("NitroFX", ShipController.Instance.GetTransform().position, ShipController.Instance.GetTransform().rotation);
            LevelManager.Instance.StartNitro();
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Ship")
        {
            LevelManager.Instance.StopNitro();
            Destroy(gameObject);
        }
    }

    private void KillParticleLine()
    {
        P1.SetActive(false);
        P2.SetActive(false);
    }
}
