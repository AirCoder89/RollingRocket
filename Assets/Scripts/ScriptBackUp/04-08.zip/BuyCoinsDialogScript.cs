﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BuyCoinsDialogScript : MonoBehaviour {
    public static bool isOpen = false;
    [SerializeField] private Button CloseBtn;
    [SerializeField] private Button Buy1KBtn;
    [SerializeField] private Button Buy5KBtn;
    [SerializeField] private Button Buy10KBtn;
    // Use this for initialization
   public void Show()
    {
        if(!isOpen)
        {
            GetComponent<Animator>().SetTrigger("open");
            isOpen = true;
            CloseBtn.onClick.AddListener(CloseMe);
            Buy1KBtn.onClick.AddListener(onBuy1kCoins);
            Buy5KBtn.onClick.AddListener(onBuy5kCoins);
            Buy10KBtn.onClick.AddListener(onBuy10kCoins);
        }
    }

    public void CloseMe()
    {
        GetComponent<Animator>().SetTrigger("close");
    }

    public void EndAnimation()
    {
        if(isOpen)
        {
            isOpen = false;
            this.gameObject.SetActive(false);
        }
    }

    public void onBuy1kCoins()
    {
        Purchaser.Instance.Buy1KCoins();
        CloseMe();
    }

    public void onBuy5kCoins()
    {
        Purchaser.Instance.Buy5KCoins();
        CloseMe();
    }

    public void onBuy10kCoins()
    {
        Purchaser.Instance.Buy10KCoins();
        CloseMe();
    }
}
