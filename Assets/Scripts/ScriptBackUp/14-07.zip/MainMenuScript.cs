﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuScript : MonoBehaviour {
    
    // Use this for initialization
    void Start () {
        PlayerPrefs.SetInt("LateContinue", 0);
        PlayerPrefs.SetInt("isContinue", 0);
        PlayerPrefs.SetInt("isCheckPoint", 0);
    }
	
    public void onClickStart()
    {
        //SceneHandler.GetInstance().LoadLevel("Level01",true);
        LoadingBarScript.Instance.LoadScene("Level01","level");
    }

    public void GotoLevelX()
    {
        LoadingBarScript.Instance.LoadScene("Level0X", "level");
    }
}
