﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelWinHandler : MonoBehaviour {
    [SerializeField] private Text CollectedCoinsTxt;
    [SerializeField] private Text BonusCoins;
   
	void Start () {
        CollectedCoinsTxt.text = SceneHandler.GetInstance().GetLevelCoins().ToString();
        BonusCoins.text = SceneHandler.GetInstance().GetBonusLevel().ToString();
    }
	
    public void GoNextLevel()
    {
        SceneHandler.GetInstance().RemoveCheckPoint();
        SceneHandler.GetInstance().ResetLevelCoins();
        LoadingBarScript.Instance.LoadScene(SceneHandler.GetInstance().GetNextLevelName(), "level");
    }

    public void GoRepeatLevel()
    {
        SceneHandler.GetInstance().RemoveCheckPoint();
        SceneHandler.GetInstance().ResetLevelCoins();
        LoadingBarScript.Instance.LoadScene(SceneHandler.GetInstance().GetCurrentLevelName(), "level");
    }

    public void GoMainMenu()
    {
        SceneHandler.GetInstance().RemoveCheckPoint();
        SceneHandler.GetInstance().ResetLevelCoins();
        LoadingBarScript.Instance.LoadScene("MainMenu", "mainMenu");
        
    }
}
