﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Advertisements;
//using admob;
using System;

public class AdManager : MonoBehaviour {
    public Text TextResult;
    private string debugTxt = "";
    private ShowOptions AdSO;
    
    private string placementId = "rewardedVideo"; //ID reward Video (unity Ads)
    public static AdManager Instance { set; get; }
	// Use this for initialization
	void Start () {
        Instance = this;
        if (Advertisement.isSupported)
        {
            Advertisement.Initialize("2661719",false);
        }
        
        /*
        #if UNITY_EDITOR
        #elif UNITY_ANDROID

                    Admob.Instance().initAdmob(bannerID,fullID);
                    Admob.Instance().setTesting(true);
                    Admob.Instance().loadInterstitial();
        #endif*/
    }
   
    public void UnityAd_Show()
    {
        print("Show Unity AD");
        AdSO = new ShowOptions();
        AdSO.resultCallback = HandleShowResult;

        Advertisement.Show("rewardedVideo", AdSO);
    }
    private void Update()
    {
       // TextResult.text = "IsReady: " + Advertisement.IsReady(placementId) + " | " + debugTxt;
    }
    private void HandleShowResult(ShowResult VideoResult)
    {
        switch(VideoResult)
        {
            case ShowResult.Failed: RewardVideoFailed(); break;
            case ShowResult.Skipped: RewardVideoSkipped(); break;
            case ShowResult.Finished: RewardVideoFinished(); break;
        }
    }

    private void RewardVideoFailed()
    {
        print("UnityAds >> Reward Failed");
        debugTxt = "Reward Failed";
    }
    private void RewardVideoSkipped()
    {
        print("UnityAds >> Reward Skipped");
        debugTxt = "Reward Skipped";
    }
    private void RewardVideoFinished()
    {
        print("UnityAds >> Reward Finished");
        debugTxt = "Reward Finished";
    }
}
