﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventHandler : MonoBehaviour {

    public delegate void Events();
   
    public static event Events onhitCoin;
    public static event Events onhitMagnet;
    public static event Events onhitFuel;
    public static event Events onShipDieEvent;
    public static event Events onStartGame;
    public static event Events onFuelEmptyEvent;
    public static event Events onClickContinueEvent;
    public static event Events onClickRestartEvent;
    public static event Events onLevelWinEvent;
    public static event Events onEndOfLevelEvent; //to stop camera follow in the end of level


    public static void onHitMagnet_TR()
    {
        if (onhitMagnet != null) onhitMagnet();
    }
    public static void LevelInTheEnd_TR()
    {
        if (onEndOfLevelEvent != null) onEndOfLevelEvent();
    }
    public static void LevelWin_TR()
    {
        if (onLevelWinEvent != null) onLevelWinEvent();
    }
    public static void onContinue_TR()
    {
        if (onClickContinueEvent != null) onClickContinueEvent();
    }
    public static void onRestart_TR()
    {
        if (onClickRestartEvent != null) onClickRestartEvent();
    }
    public static void HitFuel_TR()
    {
        if (onhitFuel != null) onhitFuel();
    }
    public static void FuelEmpty_TR()
    {
        if (onFuelEmptyEvent != null) onFuelEmptyEvent();
    }
    public static void GameStarted_TR()
    {
        if (onStartGame != null) onStartGame();
    }
    public static void ShipDie_TR()
    {
        if (onShipDieEvent != null) onShipDieEvent();
    }

    public static void HitCoinEvent()
    {
        if (onhitCoin != null) onhitCoin();
    }
}
