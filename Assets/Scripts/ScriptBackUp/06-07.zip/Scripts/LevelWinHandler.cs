﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelWinHandler : MonoBehaviour {
    public Text CollectedCoinsTxt;
    public Text BonusCoins;
   // public Text TotalCoins;
    
	// Use this for initialization
	void Start () {
        CollectedCoinsTxt.text = SceneHandler.GetInstance().GetLevelCoins().ToString();
        BonusCoins.text = SceneHandler.GetInstance().GetBonusLevel().ToString();
    }
	
    public void GoNextLevel()
    {
        SceneHandler.GetInstance().LoadLevel(SceneHandler.GetInstance().GetNextLevelName(),true);
    }

    public void GoRepeatLevel()
    {
        SceneHandler.GetInstance().LoadLevel(SceneHandler.GetInstance().GetCurrentLevelName(),true);
    }

    public void GoMainMenu()
    {
        SceneHandler.GetInstance().LoadLevel("MainMenu",false);
    }
}
