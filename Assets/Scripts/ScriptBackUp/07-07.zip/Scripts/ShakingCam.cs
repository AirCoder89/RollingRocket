﻿
using UnityEngine;
using EZCameraShake;

public class ShakingCam : MonoBehaviour {

    CameraShaker CShaker;
	// Use this for initialization
	void Start () {
        CShaker = GetComponent<CameraShaker>();
        EventHandler.onShipDieEvent += Shake;
	}

    public void Shake()
    {
        CShaker.ShakeOnce(1f, 6f, .1f, 1f);
    }
	
}
