﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlowMotionScript : MonoBehaviour {
    private bool isOnSlowMotion = false;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Ship")
        {
          
            SceneHandler.GetInstance().StartSlowMotion();
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Ship")
        {
            print("onTrigger Exit");
            SceneHandler.GetInstance().StopSlowMotion();
        }
    }
}
