﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LoadingBarScript : MonoBehaviour {

    public static LoadingBarScript Instance;
    
    public GameObject PanelLoading;
    public Text loadingText;
    public Slider sliderBar;
    private bool isBlackPanel;
    
    void Start () {

        Instance = this;
        isBlackPanel = false;
        //Hide Slider Progress Bar in start
        PanelLoading.gameObject.SetActive(false);
		
	}
	
    public void LoadScene(string SceneName,string sceneType)
    {
        if (sceneType == "level")
        {
            isBlackPanel = false;
            SceneHandler.GetInstance().SetCurrentLevelName(SceneName);
        }else if (sceneType == "win")
        {
            //hide everything in the panel (just a black)
            isBlackPanel = true;
            loadingText.gameObject.SetActive(false);
            sliderBar.gameObject.SetActive(false);
        }
        else
        {
            isBlackPanel = false;
        }
        PanelLoading.gameObject.SetActive(true);
        loadingText.text = "Loading [Starting]";
        StartCoroutine(LoadNewScene(SceneName));
    }
	
    
    IEnumerator LoadNewScene(string sceneName) {

        AsyncOperation async = SceneManager.LoadSceneAsync(sceneName);

        while (!async.isDone)
        {
            if(!isBlackPanel)
            {
                float progress = Mathf.Clamp01(async.progress / 0.9f);
                sliderBar.value = progress;
                loadingText.text = "Loading [" + progress * 100f + "%]";
            }
           
            yield return null;

        }

    }

}
