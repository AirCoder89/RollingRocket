﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FuelProgressBar : MonoBehaviour {
    
    private float Ratio = 0;
    private float currentFuelAmount;
    private float MaxFuel;
	void Start () {
       
        EventHandler.onhitFuel += onhitfuel;
    }

    public void onhitfuel()
    {
        this.AddFuel(200);
    }

    public void InitProgressBar(float CurrentFuel)
    {
        this.currentFuelAmount = CurrentFuel;
        this.MaxFuel = SceneHandler.GetInstance().GetMaxFuel();
       
    }
    public void AddFuel(float fuelAmount)
    {
        currentFuelAmount += fuelAmount;
        if (currentFuelAmount > MaxFuel)
        {
            currentFuelAmount = MaxFuel;
        }

     
    }

    public void ConsumeFuel(float consumeAmount)
    {
      
        currentFuelAmount -= consumeAmount;

        if (currentFuelAmount < 0)
        {
            currentFuelAmount = 0;
            EventHandler.FuelEmpty_TR();
        }
       
       
    }
    
    private void Update()
    {
        Ratio = Mathf.Lerp(Ratio, this.currentFuelAmount / this.MaxFuel, 4f * Time.deltaTime) ;
        GameObject.FindGameObjectWithTag("FillProgressBar").GetComponent<Image>().fillAmount = Ratio;
        GameObject.FindGameObjectWithTag("FuelIndicatorTxt").GetComponent<Text>().text = (Ratio * 100).ToString("0") + "%";
    }
}
