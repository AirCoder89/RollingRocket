﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndOfLevelScript : MonoBehaviour {

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Ship")
        {
            print("level win");
            EventHandler.LevelInTheEnd_TR();
        }
    }
}
