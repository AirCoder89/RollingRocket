﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lowFuelScript : MonoBehaviour {

    
    private Animator anim;
	void Start () {
        anim = GetComponent<Animator>();

    }
	public void LowFuel()
    {
        anim.SetTrigger("low");
    }

    public void FullFuel()
    {
        anim.SetTrigger("full");
    }
}
