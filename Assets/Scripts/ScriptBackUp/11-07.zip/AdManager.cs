﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Advertisements;
//using admob;
using System;

public class AdManager : MonoBehaviour {
    public static AdManager Instance { set; get; }
    
    private string debugTxt = "";
    private ShowOptions AdSO;
    
    private string placementId = "rewardedVideo"; //ID reward Video (unity Ads)
    [HideInInspector] public bool RealTimeNotworkStatus;
    private bool CheckRealTime;
	// Use this for initialization
	void Start () {
        Instance = this;
        if (Advertisement.isSupported)
        {
            Advertisement.Initialize("2661719",false);
        }

        CheckRealTime = false;
        /*
        #if UNITY_EDITOR
        #elif UNITY_ANDROID

                    Admob.Instance().initAdmob(bannerID,fullID);
                    Admob.Instance().setTesting(true);
                    Admob.Instance().loadInterstitial();
        #endif*/
    }

    public bool IsVideoReadyToShow()
    {
        return Advertisement.IsReady(placementId);
    }
    public void RealTimeNetworkAvailable(bool startCheck)
    {
        CheckRealTime = startCheck;
    }
    public bool IsNetworkAvailable()
    {
       
        if(Application.internetReachability != NetworkReachability.NotReachable)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public void UnityAd_Show()
    {
        AdSO = new ShowOptions();
        AdSO.resultCallback = HandleShowResult;

        Advertisement.Show("rewardedVideo", AdSO);
    }
    private void Update()
    {
       if(!CheckRealTime)
        {
            return;
        }
        else
        {
            RealTimeNotworkStatus = IsNetworkAvailable();
        }
    }
   
    private void HandleShowResult(ShowResult VideoResult)
    {
        switch(VideoResult)
        {
            case ShowResult.Failed: RewardVideoFailed(); break;
            case ShowResult.Skipped: RewardVideoSkipped(); break;
            case ShowResult.Finished: RewardVideoFinished(); break;
        }
    }

    private void RewardVideoFailed()
    {
        print("UnityAds >> Reward Failed");
        EventHandler.RewardVideoFailed_TR();
    }
    private void RewardVideoSkipped()
    {
        print("UnityAds >> Reward Skipped");
        EventHandler.RewardVideoSkiped_TR();
        
    }
    private void RewardVideoFinished()
    {
        print("UnityAds >> Reward Finished");
        EventHandler.RewardVideoComplete_TR();
    }
}
