﻿
using UnityEngine;
using UnityEngine.UI;

public class PauseMenuScript : MonoBehaviour {

   /* [SerializeField] private Button StoreBtn;
    [SerializeField] private Button SettingsBtn;
    [SerializeField] private Button ExitGameBtn;
    //[SerializeField] private Button ResumeGameBtn;
    [SerializeField] private Button ReplayGameBtn;*/
    
   /* void Start () {
       
        StoreBtn.onClick.AddListener(onClickStore);
        SettingsBtn.onClick.AddListener(onClickSettings);
        ExitGameBtn.onClick.AddListener(onClickExitGame);
        //ResumeGameBtn.onClick.AddListener(onClickResume);
        ReplayGameBtn.onClick.AddListener(onClickReplay);
    }*/


    public void OpenMenu()
    {
       
            this.gameObject.SetActive(true);
            LevelManager.Instance.PauseGame();
          
    }

    public void CloseMenu()
    {
       
            this.gameObject.SetActive(false);
            LevelManager.Instance.ResumeGame();
        
    }
    public void onClickStore()
    {
        print("Click");
        // CloseMenu();
    }

    public void onClickSettings()
    {
        print("Click");
        //CloseMenu();
    }

    public void onClickExitGame()
    {
        print("Click");
        CloseMenu();
        LoadingBarScript.Instance.LoadScene("MainMenu", "mainMenu");
    }

    public void onClickResume()
    {
        print("Click");
        CloseMenu();
    }

    public void onClickReplay()
    {
        CloseMenu();
        LevelManager.Instance.RestartLevel();
    }


}
