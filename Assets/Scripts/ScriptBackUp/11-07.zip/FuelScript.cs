﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FuelScript : MonoBehaviour {
    private ObjectPooler Pool;

    void Start()
    {
        Pool = ObjectPooler.Instance;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Ship")
        {
			
            Pool.SpawnFromPool("FuelFX", transform.position, Quaternion.identity);
            Destroy(this.gameObject);
			
            LevelManager.Instance.HitFuel();
        }
    }
}
