﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class coinsScript : MonoBehaviour {

   
    private float speed = 8f;
    private ObjectPooler Pool;
    public float Speed { set { speed = value; } get { return speed; } }
    // Use this for initialization
    void Start () {
        Pool = ObjectPooler.Instance;
    }
    public void tweenTo(Vector3 pos)
    {
        speed = 8f;
        transform.position = Vector3.Lerp(transform.position, pos, speed * Time.deltaTime);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Ship")
        {
            print("Hit Coin");
                EventHandler.HitCoinEvent();
                Pool.SpawnFromPool("CoinFX", transform.position, Quaternion.identity);
                Destroy(gameObject);
        }
    }
}
