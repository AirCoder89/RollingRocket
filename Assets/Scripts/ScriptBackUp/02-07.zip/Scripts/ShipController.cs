﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShipController : MonoBehaviour {

    
    public GameObject ExploseFX;
    public GameObject GoTxt;
    public Text DistanceTxt;
    public Text CoinsTxt;
    [Range(40, 300)]  public float LevelSpeed = 80f;
    public float gravity = 0.1f;
    [Range(0, 1)] public float thrust = 0.25f;
    [Range(8, 20)] public float RotationSpeed = 10f;
    private float XSpeed = 8f;
    private float YSpeed = 0f;
    private bool Engine = false;
    [Range(100, 5000)] public float Fuel = 1000f;
    private bool FuelIsEmpty = false;
    
    private float _distance;
    private Quaternion rotation;
    private Rigidbody2D RG;
    
    
    public bool isOnMagnet = true;
    public bool isGameStarted = false;

    public GameObject Particle1;
    public GameObject Particle2;
    private HealthBarFuel HealthBar;
    private float FuelConsume = 1f;
    // Use this for initialization
    private void Awake()
    {
        RG = GetComponent<Rigidbody2D>();
        RG.gravityScale = 0f;
    }
    void Start () {
        HealthBar = GameObject.FindGameObjectWithTag("levelManager").GetComponent<HealthBarFuel>();
        
        FuelIsEmpty = false;
        _distance = 0f;
        CoinsTxt.text = SceneHandler.GetInstance().GetLevelCoins().ToString();
        
        EventHandler.onFuelEmptyEvent += fuelEmpty;
        EventHandler.onLevelWinEvent += onLevelWin;
    }

    public void onLevelWin()
    {
        EventHandler.onLevelWinEvent -= onLevelWin;
        //gameObject.SetActive(false);
        SceneHandler.GetInstance().SetFinalDistance(_distance);
        //if(gameObject != null)
       //GetComponentInChildren<SpriteRenderer>().enabled = false;
        isGameStarted = false;
       
    }
    public void fuelEmpty()
    {
        FuelIsEmpty = true;
    }
    public void InitShip()
    {
        //called by LevelManager
        FuelIsEmpty = false;
    }
   
    public void SetOnMagnet()
    {
        this.isOnMagnet = !this.isOnMagnet;
    }
   
    private void AddGoTxt()
    {
        Instantiate(GoTxt, new Vector3(18f, 4f, 0), transform.rotation);
    }
    IEnumerator onstartGame()
    {
        Particle1.SetActive(true);
        Particle2.SetActive(true);
        Lean.Touch.LeanScale LS = GetComponent<Lean.Touch.LeanScale>();
        LS.enabled = true;

		
		if (SceneHandler.GetInstance().isLateContinue()) {
            SceneHandler.GetInstance().SetIsLateContinue(false);

            RG.AddForce(new Vector2(120f, 0), ForceMode2D.Impulse);
		} else {
			RG.AddForce(new Vector2(210f, 0), ForceMode2D.Impulse);
		}
       
        yield return new WaitForSeconds(0.65f);
        isGameStarted = true;
        AddGoTxt();
        EventHandler.GameStarted_TR();
    }
	// Update is called once per frame
	void Update () {
        //GUI
        CoinsTxt.text = SceneHandler.GetInstance().GetLevelCoins().ToString();
        //----------------------
        //trigger start game
        if (Input.GetButtonDown("Fire1") && !isGameStarted)
        {
            StartCoroutine("onstartGame");
        }


        if (isGameStarted)
        {
            
            if (Input.GetButtonDown("Fire1"))
            {
                Engine = true;
            }
            if (Input.GetButtonUp("Fire1"))
            {
                Engine = false;
            }
            
        } //>Game Started

    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.collider.gameObject.layer == LayerMask.NameToLayer("PlatformLayer"))
        {
            EventHandler.ShipDie_TR();
            //Instantiate(ExploseFX, transform.position, transform.rotation);
            ObjectPooler.Instance.SpawnFromPool("ExploseFX", transform.position, Quaternion.identity);
            Destroy(gameObject);
        } 
    }
    private void OnTriggerStay2D(Collider2D other)
    {
        //magnet
        if (isOnMagnet)
        {
            if(other.gameObject.tag == "Coin")
            {
                coinsScript coin = other.gameObject.GetComponent<coinsScript>();
                coin.tweenTo(transform.position);
                
            }
        }
        
    } //on Magnet
    private void FixedUpdate()
    {
        if(isGameStarted)
        {
            if (Engine && !FuelIsEmpty)
            {
                YSpeed += thrust;
                HealthBar.ConsumeFuel(this.FuelConsume);
            }
            
            _distance += XSpeed;
            DistanceTxt.text = "Distance: " + _distance.ToString();
            ///FuelTxt.text = "Fuel: " + Fuel.ToString();
            RG.velocity = new Vector2(LevelSpeed * XSpeed * Time.deltaTime, RG.velocity.y);

            YSpeed -= gravity;
            Vector2 OldPos = transform.position;
            OldPos.y += (YSpeed * Time.deltaTime);
            transform.position = OldPos;

            float angle;
            angle = Mathf.Atan2(YSpeed, XSpeed) * Mathf.Rad2Deg;
            rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotation, RotationSpeed * Time.deltaTime);

        }//> Game Started

    }
    
    public Quaternion getRotation()
    {
        return rotation;
    }
  

    public SpriteRenderer GetSprite()
    {
        return GetComponent<SpriteRenderer>();
    }

    
}
