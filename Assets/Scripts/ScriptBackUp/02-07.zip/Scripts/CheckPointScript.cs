﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckPointScript : MonoBehaviour {
    static protected int TotalCheckPt = 0;
    private int ID;
	public float XCheckPoint;
	public float YCheckPoint;
    public static void ResetID()
    {
        TotalCheckPt = 0;
    }
    private void Awake()
    {
        TotalCheckPt++;
        ID = TotalCheckPt;
    }
    public int GetID()
    {
        return ID;
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "Ship")
        {
            //save Player X and Y
            SceneHandler.GetInstance().SetCheckPoint(ID, XCheckPoint, YCheckPoint);
            Destroy(gameObject);
        }
    }

}
