﻿using UnityEngine;


public class ShipFollow : MonoBehaviour {
    public Transform target;
    public Transform Moon;
    public Transform StarsSP;
    public Vector3 offset ;
    public float Xoffset; //Ship x on the screen
    public float YScale; //lock at scale
    [Range(0,500)] public float Smoothing;
    //private Vector2 SmoothVelocity; 

    private float YOffset;
    private bool ShipAlive;

    private Vector3 moonOffset;
    private void Awake()
    {

        offset = new Vector3(0f, 0f, -15f);
        Xoffset = 8f;
        YScale = 4f;
    }
    private void Start()
    {
        moonOffset = transform.position + Moon.position;
        ShipAlive = true;
        EventHandler.onShipDieEvent += OnShipDie;
        EventHandler.onEndOfLevelEvent += onLevelEnd;
    }
    public void onLevelEnd()
    {
        EventHandler.onEndOfLevelEvent -= onLevelEnd;
        ShipAlive = false;
    }
  
    public void OnShipDie()
    {
        EventHandler.onShipDieEvent -= OnShipDie;
        ShipAlive = false; //to stop following the ship after we destroy it
    }
    
    private void LateUpdate() //FixedUpdate
{
      if(ShipAlive)
        {
            //---try 1
            //transform.position = new Vector3(target.position.x + Xoffset, 0, 0) + offset;
            //---

            //--- try 2
            /*Vector3 _pos = new Vector3(target.position.x + Xoffset, 0, 0) + offset;
             Vector3 smoothedPos = Vector3.Lerp(transform.position, _pos, Smoothing * Time.deltaTime );
             transform.position = smoothedPos;*/
            //---

            //----- try 3
           /*Vector3 v3 = transform.position;
             v3.x = Mathf.Lerp(v3.x, target.position.x + Xoffset, Smoothing * Time.deltaTime);
             transform.position = v3;*/
            //-----

            //--- try 4
            Vector3 _pos = new Vector3(target.position.x + Xoffset, 0, 0) + offset;
             Vector3 smoothedPos = Vector3.Slerp(transform.position, _pos, Smoothing * Time.deltaTime);
             transform.position = smoothedPos;
            //---

            //----- try 5
           // transform.position = new Vector3(Mathf.SmoothDamp(transform.position.x, target.position.x + Xoffset, ref SmoothVelocity.x, Smoothing * Time.deltaTime), transform.position.y, transform.position.z);
            //-----

            YOffset = target.position.y - (target.position.y / YScale);
            Vector3 lockatPos = new Vector3(target.position.x + Xoffset, target.position.y - YOffset, 0);
            transform.LookAt(lockatPos);
            //stars
            StarsSP.position = new Vector3(target.position.x + 15f, 0, 0);


            Moon.position = transform.position + moonOffset - new Vector3(70f,0,0);
        }
       
    }

   
}
