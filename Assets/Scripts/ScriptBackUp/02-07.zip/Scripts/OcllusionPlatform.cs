﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OcllusionPlatform : MonoBehaviour {
   
    private GameObject Player;
    private float distance;
    
    // Use this for initialization
    void Start()
    {
        Player = GameObject.FindGameObjectWithTag("ShipParent");
        distance = Camera.main.ScreenToWorldPoint(new Vector3(Camera.main.pixelWidth * 2f, 0, 0)).x + 20f;
    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {
            bool isActive = Mathf.Abs(Mathf.Abs(transform.position.x) - Mathf.Abs(Player.transform.position.x)) < distance;
			GetComponent<EdgeCollider2D>().enabled = isActive;
			GetComponent<SpriteRenderer>().enabled = isActive;
			if(GetComponent<Animator>())
            {
				GetComponent<Animator>().enabled = isActive;
            }
        }

    }
}
