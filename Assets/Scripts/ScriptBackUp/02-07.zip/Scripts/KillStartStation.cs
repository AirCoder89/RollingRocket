﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillStartStation : MonoBehaviour {

	// Use this for initialization
	void Start () {
        EventHandler.onStartGame += KillMe;
	}
	
	public void KillMe()
    {
        if(gameObject != null)
        {
            EventHandler.onStartGame -= KillMe;
            Destroy(gameObject, 3f);
        }
       
    }
}
