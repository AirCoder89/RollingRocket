﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour {
   
   
    private GameObject ship;

    public GameObject Ship { get { return ship; } set { ship = value; } }
    private ShipController ShipScript;
    private HealthBarFuel HPFuel;
	// Use this for initialization
	void Start () {

        EventHandler.onClickContinueEvent += ContinueLevel;
        EventHandler.onClickRestartEvent += RestartLevel;
        EventHandler.onLevelWinEvent += onLevelWin;
        HPFuel = GetComponent<HealthBarFuel>();
        Ship = GameObject.FindGameObjectWithTag("ShipParent");
        ShipScript = ship.GetComponent<ShipController>();
        

        if (SceneManager.GetActiveScene().name == "Level01") InitLevel01();
        else if (SceneManager.GetActiveScene().name == "Level02") InitLevel02();

        AfterInit();
    }
   
    public void onLevelWin()
    {
        EventHandler.onLevelWinEvent -= onLevelWin;
    }
    //************* Init Levels
    private void InitLevel01()
    {
        HPFuel.InitHP(SceneHandler.GetInstance().getMaxFuel(), 400);
        ShipScript.InitShip();
    }
    private void InitLevel02()
    {
        
    }



	private void AfterInit()
	{
		if (SceneHandler.GetInstance().isContinue() && SceneHandler.GetInstance().isCheckedPoint()) {
            //set the player position
            ship.transform.position = SceneHandler.GetInstance().GetSavedPosition();
            SceneHandler.GetInstance().RemoveLastCheckPointFromScene();
            SceneHandler.GetInstance().SetIsContinue(false);
            SceneHandler.GetInstance().SetIsLateContinue(true);
		}
	}
    //********************************************
	//---------- Restart Level
    public void RestartLevel()
    {
        EventHandler.onClickRestartEvent -= RestartLevel;
        SceneHandler.GetInstance().RemoveCheckPoint();
        SceneHandler.GetInstance().ResetLevelCoins();
        SceneHandler.GetInstance().LoadLevel(SceneManager.GetActiveScene().name,true);
    }

	//-------- Continue Level
    
    public void ContinueLevel()
    {
        EventHandler.onClickContinueEvent -= ContinueLevel;
        if (SceneHandler.GetInstance().isCheckedPoint()) {

            //-- set Continue flag to true
            SceneHandler.GetInstance().SetIsContinue(true);

            //restart level
            SceneHandler.GetInstance().LoadLevel(SceneManager.GetActiveScene().name,true);
        }
       
    }
}
